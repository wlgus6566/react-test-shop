import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/OrderPage/Products.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=73008799"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Products.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=73008799"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { useWishlist } from "/src/contexts/WishlistContext.jsx";
function Products({
  name,
  imagePath,
  updateItemCount
}) {
  _s();
  const {
    isInWishlist,
    addToWishlist,
    removeFromWishlist
  } = useWishlist();
  const handleChange = (event) => {
    const currentValue = event.target.value;
    updateItemCount(name, currentValue);
  };
  const handleWishClick = (e) => {
    e.preventDefault();
    if (isInWishlist(name)) {
      removeFromWishlist(name);
    } else {
      addToWishlist({
        name,
        imagePath
      });
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { style: {
    textAlign: "center",
    position: "relative"
  }, children: [
    /* @__PURE__ */ jsxDEV("button", { onClick: handleWishClick, className: "wish-button", style: {
      position: "absolute",
      right: "15%",
      top: "10px",
      background: "none",
      border: "none",
      fontSize: "1.5rem",
      cursor: "pointer",
      zIndex: 1
    }, "aria-label": isInWishlist(name) ? "찜하기 취소" : "찜하기", children: isInWishlist(name) ? "❤️" : "🤍" }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Products.jsx",
      lineNumber: 34,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("img", { style: {
      width: "75%"
    }, src: `http://localhost:5003/${imagePath}`, alt: `${name} product` }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Products.jsx",
      lineNumber: 46,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { style: {
      marginTop: "10px"
    }, children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: name, style: {
        textAlign: "right"
      }, children: name }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Products.jsx",
        lineNumber: 52,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { id: name, style: {
        marginLeft: 7
      }, type: "number", className: "form-number", name: "quantity", min: "0", defaultValue: 0, onChange: handleChange }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Products.jsx",
        lineNumber: 57,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Products.jsx",
      lineNumber: 49,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Products.jsx",
    lineNumber: 30,
    columnNumber: 10
  }, this);
}
_s(Products, "JAUufftp1xyQXdoatuMEYK/4Dl0=", false, function() {
  return [useWishlist];
});
_c = Products;
export default Products;
var _c;
$RefreshReg$(_c, "Products");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Products.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRCTixPQUFPQSxXQUFXO0FBQ2xCLFNBQVNDLG1CQUFtQjtBQUU1QixTQUFTQyxTQUFTO0FBQUEsRUFBRUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBV0M7QUFBZ0IsR0FBRztBQUFBQyxLQUFBO0FBQ3RELFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFjQztBQUFBQSxJQUFlQztBQUFBQSxFQUFtQixJQUFJUixZQUFZO0FBRXhFLFFBQU1TLGVBQWdCQyxXQUFVO0FBQzlCLFVBQU1DLGVBQWVELE1BQU1FLE9BQU9DO0FBQ2xDVCxvQkFBZ0JGLE1BQU1TLFlBQVk7QUFBQSxFQUNwQztBQUVBLFFBQU1HLGtCQUFtQkMsT0FBTTtBQUM3QkEsTUFBRUMsZUFBZTtBQUNqQixRQUFJVixhQUFhSixJQUFJLEdBQUc7QUFDdEJNLHlCQUFtQk4sSUFBSTtBQUFBLElBQ3pCLE9BQU87QUFDTEssb0JBQWM7QUFBQSxRQUFFTDtBQUFBQSxRQUFNQztBQUFBQSxNQUFVLENBQUM7QUFBQSxJQUNuQztBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksT0FBTztBQUFBLElBQUVjLFdBQVc7QUFBQSxJQUFVQyxVQUFVO0FBQUEsRUFBVyxHQUN0RDtBQUFBLDJCQUFDLFlBQ0MsU0FBU0osaUJBQ1QsV0FBVSxlQUNWLE9BQU87QUFBQSxNQUNMSSxVQUFVO0FBQUEsTUFDVkMsT0FBTztBQUFBLE1BQ1BDLEtBQUs7QUFBQSxNQUNMQyxZQUFZO0FBQUEsTUFDWkMsUUFBUTtBQUFBLE1BQ1JDLFVBQVU7QUFBQSxNQUNWQyxRQUFRO0FBQUEsTUFDUkMsUUFBUTtBQUFBLElBQ1YsR0FDQSxjQUFZbkIsYUFBYUosSUFBSSxJQUFJLFdBQVcsT0FFM0NJLHVCQUFhSixJQUFJLElBQUksT0FBTyxRQWYvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsSUFDQSx1QkFBQyxTQUNDLE9BQU87QUFBQSxNQUFFd0IsT0FBTztBQUFBLElBQU0sR0FDdEIsS0FBTSx5QkFBd0J2QixTQUFVLElBQ3hDLEtBQU0sR0FBRUQsSUFBSyxjQUhmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHeUI7QUFBQSxJQUV6Qix1QkFBQyxVQUFLLE9BQU87QUFBQSxNQUFFeUIsV0FBVztBQUFBLElBQU8sR0FDL0I7QUFBQSw2QkFBQyxXQUFNLFNBQVN6QixNQUFNLE9BQU87QUFBQSxRQUFFZSxXQUFXO0FBQUEsTUFBUSxHQUMvQ2Ysa0JBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxXQUNDLElBQUlBLE1BQ0osT0FBTztBQUFBLFFBQUUwQixZQUFZO0FBQUEsTUFBRSxHQUN2QixNQUFLLFVBQ0wsV0FBVSxlQUNWLE1BQUssWUFDTCxLQUFJLEtBQ0osY0FBYyxHQUNkLFVBQVVuQixnQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUXlCO0FBQUEsU0FaM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNBO0FBQUEsT0FyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNDQTtBQUVKO0FBQUNKLEdBMURRSixVQUFRO0FBQUEsVUFDNkNELFdBQVc7QUFBQTtBQUFBNkIsS0FEaEU1QjtBQTREVCxlQUFlQTtBQUFTLElBQUE0QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VXaXNobGlzdCIsIlByb2R1Y3RzIiwibmFtZSIsImltYWdlUGF0aCIsInVwZGF0ZUl0ZW1Db3VudCIsIl9zIiwiaXNJbldpc2hsaXN0IiwiYWRkVG9XaXNobGlzdCIsInJlbW92ZUZyb21XaXNobGlzdCIsImhhbmRsZUNoYW5nZSIsImV2ZW50IiwiY3VycmVudFZhbHVlIiwidGFyZ2V0IiwidmFsdWUiLCJoYW5kbGVXaXNoQ2xpY2siLCJlIiwicHJldmVudERlZmF1bHQiLCJ0ZXh0QWxpZ24iLCJwb3NpdGlvbiIsInJpZ2h0IiwidG9wIiwiYmFja2dyb3VuZCIsImJvcmRlciIsImZvbnRTaXplIiwiY3Vyc29yIiwiekluZGV4Iiwid2lkdGgiLCJtYXJnaW5Ub3AiLCJtYXJnaW5MZWZ0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQcm9kdWN0cy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlV2lzaGxpc3QgfSBmcm9tIFwiLi4vLi4vY29udGV4dHMvV2lzaGxpc3RDb250ZXh0XCI7XG5cbmZ1bmN0aW9uIFByb2R1Y3RzKHsgbmFtZSwgaW1hZ2VQYXRoLCB1cGRhdGVJdGVtQ291bnQgfSkge1xuICBjb25zdCB7IGlzSW5XaXNobGlzdCwgYWRkVG9XaXNobGlzdCwgcmVtb3ZlRnJvbVdpc2hsaXN0IH0gPSB1c2VXaXNobGlzdCgpO1xuICBcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGV2ZW50KSA9PiB7XG4gICAgY29uc3QgY3VycmVudFZhbHVlID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xuICAgIHVwZGF0ZUl0ZW1Db3VudChuYW1lLCBjdXJyZW50VmFsdWUpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVdpc2hDbGljayA9IChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmIChpc0luV2lzaGxpc3QobmFtZSkpIHtcbiAgICAgIHJlbW92ZUZyb21XaXNobGlzdChuYW1lKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYWRkVG9XaXNobGlzdCh7IG5hbWUsIGltYWdlUGF0aCB9KTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHN0eWxlPXt7IHRleHRBbGlnbjogXCJjZW50ZXJcIiwgcG9zaXRpb246IFwicmVsYXRpdmVcIiB9fT5cbiAgICAgIDxidXR0b25cbiAgICAgICAgb25DbGljaz17aGFuZGxlV2lzaENsaWNrfVxuICAgICAgICBjbGFzc05hbWU9XCJ3aXNoLWJ1dHRvblwiXG4gICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgICAgICAgICByaWdodDogXCIxNSVcIixcbiAgICAgICAgICB0b3A6IFwiMTBweFwiLFxuICAgICAgICAgIGJhY2tncm91bmQ6IFwibm9uZVwiLFxuICAgICAgICAgIGJvcmRlcjogXCJub25lXCIsXG4gICAgICAgICAgZm9udFNpemU6IFwiMS41cmVtXCIsXG4gICAgICAgICAgY3Vyc29yOiBcInBvaW50ZXJcIixcbiAgICAgICAgICB6SW5kZXg6IDFcbiAgICAgICAgfX1cbiAgICAgICAgYXJpYS1sYWJlbD17aXNJbldpc2hsaXN0KG5hbWUpID8gXCLssJztlZjquLAg7Leo7IaMXCIgOiBcIuywnO2VmOq4sFwifVxuICAgICAgPlxuICAgICAgICB7aXNJbldpc2hsaXN0KG5hbWUpID8gXCLinaTvuI9cIiA6IFwi8J+kjVwifVxuICAgICAgPC9idXR0b24+XG4gICAgICA8aW1nXG4gICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjc1JVwiIH19XG4gICAgICAgIHNyYz17YGh0dHA6Ly9sb2NhbGhvc3Q6NTAwMy8ke2ltYWdlUGF0aH1gfVxuICAgICAgICBhbHQ9e2Ake25hbWV9IHByb2R1Y3RgfVxuICAgICAgLz5cbiAgICAgIDxmb3JtIHN0eWxlPXt7IG1hcmdpblRvcDogXCIxMHB4XCIgfX0+XG4gICAgICAgIDxsYWJlbCBodG1sRm9yPXtuYW1lfSBzdHlsZT17eyB0ZXh0QWxpZ246IFwicmlnaHRcIiB9fT5cbiAgICAgICAgICB7bmFtZX1cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgaWQ9e25hbWV9XG4gICAgICAgICAgc3R5bGU9e3sgbWFyZ2luTGVmdDogNyB9fVxuICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tbnVtYmVyXCJcbiAgICAgICAgICBuYW1lPVwicXVhbnRpdHlcIlxuICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgIGRlZmF1bHRWYWx1ZT17MH1cbiAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxuICAgICAgICAvPlxuICAgICAgPC9mb3JtPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBQcm9kdWN0cztcbiJdLCJmaWxlIjoiL1VzZXJzL2ppaHllb24vV2Vic3Rvcm1Qcm9qZWN0cy9yZWFjdC10ZXN0LXNob3AvcmVhY3Qtc2hvcC12aXRlLXRkZC1jbGllbnQvc3JjL3BhZ2VzL09yZGVyUGFnZS9Qcm9kdWN0cy5qc3gifQ==