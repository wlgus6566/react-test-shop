import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ErrorBanner.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=73008799"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/ErrorBanner.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
function ErrorBanner({
  message
}) {
  let errorMessage = message || "에러입니다.";
  return /* @__PURE__ */ jsxDEV("div", { "data-testid": "error-banner", style: {
    backgroundColor: "red",
    color: "white"
  }, children: errorMessage }, void 0, false, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/ErrorBanner.jsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
}
_c = ErrorBanner;
export default ErrorBanner;
var _c;
$RefreshReg$(_c, "ErrorBanner");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/ErrorBanner.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBSUk7QUFKSiwyQkFBcUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFFQTtBQUFRLEdBQUc7QUFDaEMsTUFBSUMsZUFBZUQsV0FBVztBQUU5QixTQUNFLHVCQUFDLFNBQ0MsZUFBWSxnQkFDWixPQUFPO0FBQUEsSUFBRUUsaUJBQWlCO0FBQUEsSUFBT0MsT0FBTztBQUFBLEVBQVEsR0FFL0NGLDBCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQTtBQUVKO0FBQUNHLEtBWFFDO0FBYVQsZUFBZUE7QUFBWSxJQUFBRDtBQUFBRSxhQUFBRixJQUFBIiwibmFtZXMiOlsibWVzc2FnZSIsImVycm9yTWVzc2FnZSIsImJhY2tncm91bmRDb2xvciIsImNvbG9yIiwiX2MiLCJFcnJvckJhbm5lciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkVycm9yQmFubmVyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJmdW5jdGlvbiBFcnJvckJhbm5lcih7IG1lc3NhZ2UgfSkge1xuICBsZXQgZXJyb3JNZXNzYWdlID0gbWVzc2FnZSB8fCBcIuyXkOufrOyeheuLiOuLpC5cIjtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGRhdGEtdGVzdGlkPVwiZXJyb3ItYmFubmVyXCJcbiAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogXCJyZWRcIiwgY29sb3I6IFwid2hpdGVcIiB9fVxuICAgID5cbiAgICAgIHtlcnJvck1lc3NhZ2V9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEVycm9yQmFubmVyO1xuIl0sImZpbGUiOiIvVXNlcnMvamloeWVvbi9XZWJzdG9ybVByb2plY3RzL3JlYWN0LXRlc3Qtc2hvcC9yZWFjdC1zaG9wLXZpdGUtdGRkLWNsaWVudC9zcmMvY29tcG9uZW50cy9FcnJvckJhbm5lci5qc3gifQ==