import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/contexts/OrderContext.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=73008799"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/contexts/OrderContext.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=73008799"; const createContext = __vite__cjsImport3_react["createContext"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useEffect = __vite__cjsImport3_react["useEffect"];
export const OrderContext = createContext();
const pricePerItem = {
  products: 1e3,
  options: 500
};
function calculateSubtotal(orderType, orderCounts) {
  let optionCount = 0;
  for (const count of orderCounts[orderType].values()) {
    optionCount += count;
  }
  return optionCount * pricePerItem[orderType];
}
export function OrderContextProvider(props) {
  _s();
  const [orderCounts, setOrderCounts] = useState({
    products: /* @__PURE__ */ new Map(),
    options: /* @__PURE__ */ new Map()
  });
  const [totals, setTotals] = useState({
    products: 0,
    options: 0,
    total: 0
  });
  const [userPoints, setUserPoints] = useState(5e3);
  useEffect(() => {
    if (orderCounts.products.size === 0 && orderCounts.options.size === 0) {
      setTotals({
        products: 0,
        options: 0,
        total: 0
      });
    } else {
      const productsTotal = calculateSubtotal("products", orderCounts);
      const optionsTotal = calculateSubtotal("options", orderCounts);
      setTotals({
        products: productsTotal,
        options: optionsTotal,
        total: productsTotal + optionsTotal
      });
    }
  }, [orderCounts]);
  const value = useMemo(() => {
    function updateItemCount(itemName, newItemCount, orderType) {
      const newOrderCounts = new Map(orderCounts[orderType]);
      newOrderCounts.set(itemName, parseInt(newItemCount, 10));
      setOrderCounts((prev) => ({
        ...prev,
        [orderType]: newOrderCounts
      }));
    }
    function getOrderData() {
      return {
        products: Object.fromEntries(orderCounts.products),
        options: Object.fromEntries(orderCounts.options),
        totals
      };
    }
    function resetOrderDatas() {
      console.log("🛠 주문 데이터 초기화 시작");
      setOrderCounts({
        products: /* @__PURE__ */ new Map(),
        options: /* @__PURE__ */ new Map()
      });
      setTotals({
        products: 0,
        options: 0,
        total: 0
      });
      setUserPoints(5e3);
      setTimeout(() => {
        console.log("🔄 주문 데이터 완전 초기화 완료");
      }, 50);
    }
    function deductPoints(amount) {
      setUserPoints((prev) => {
        const currentPoints = Number(prev) || 5e3;
        const validAmount = Number(amount) || 0;
        return Math.max(0, currentPoints - validAmount);
      });
    }
    return [{
      products: orderCounts.products,
      options: orderCounts.options,
      totals,
      userPoints
    }, updateItemCount, resetOrderDatas, deductPoints, getOrderData];
  }, [orderCounts, totals, userPoints]);
  return /* @__PURE__ */ jsxDEV(OrderContext.Provider, { value, ...props }, void 0, false, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/contexts/OrderContext.jsx",
    lineNumber: 115,
    columnNumber: 10
  }, this);
}
_s(OrderContextProvider, "uWDisdQ/aZkB/ET6vMYm0RS9V1g=");
_c = OrderContextProvider;
var _c;
$RefreshReg$(_c, "OrderContextProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/contexts/OrderContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUhTOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5IVCxTQUFTQSxlQUFlQyxVQUFVQyxTQUFTQyxpQkFBaUI7QUFHckQsYUFBTUMsZUFBZUosY0FBYztBQUcxQyxNQUFNSyxlQUFlO0FBQUEsRUFDbkJDLFVBQVU7QUFBQSxFQUNWQyxTQUFTO0FBQ1g7QUFHQSxTQUFTQyxrQkFBa0JDLFdBQVdDLGFBQWE7QUFDakQsTUFBSUMsY0FBYztBQUNsQixhQUFXQyxTQUFTRixZQUFZRCxTQUFTLEVBQUVJLE9BQU8sR0FBRztBQUNuREYsbUJBQWVDO0FBQUFBLEVBQ2pCO0FBQ0EsU0FBT0QsY0FBY04sYUFBYUksU0FBUztBQUM3QztBQUdPLGdCQUFTSyxxQkFBcUJDLE9BQU87QUFBQUMsS0FBQTtBQUUxQyxRQUFNLENBQUNOLGFBQWFPLGNBQWMsSUFBSWhCLFNBQVM7QUFBQSxJQUM3Q0ssVUFBVSxvQkFBSVksSUFBSTtBQUFBLElBQ2xCWCxTQUFTLG9CQUFJVyxJQUFJO0FBQUEsRUFDbkIsQ0FBQztBQUdELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJbkIsU0FBUztBQUFBLElBQ25DSyxVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RjLE9BQU87QUFBQSxFQUNULENBQUM7QUFHRCxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSXRCLFNBQVMsR0FBSTtBQUdqREUsWUFBVSxNQUFNO0FBQ2QsUUFBSU8sWUFBWUosU0FBU2tCLFNBQVMsS0FBS2QsWUFBWUgsUUFBUWlCLFNBQVMsR0FBRztBQUNyRUosZ0JBQVU7QUFBQSxRQUFFZCxVQUFVO0FBQUEsUUFBR0MsU0FBUztBQUFBLFFBQUdjLE9BQU87QUFBQSxNQUFFLENBQUM7QUFBQSxJQUNqRCxPQUFPO0FBQ0wsWUFBTUksZ0JBQWdCakIsa0JBQWtCLFlBQVlFLFdBQVc7QUFDL0QsWUFBTWdCLGVBQWVsQixrQkFBa0IsV0FBV0UsV0FBVztBQUM3RFUsZ0JBQVU7QUFBQSxRQUNSZCxVQUFVbUI7QUFBQUEsUUFDVmxCLFNBQVNtQjtBQUFBQSxRQUNUTCxPQUFPSSxnQkFBZ0JDO0FBQUFBLE1BQ3pCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixHQUFHLENBQUNoQixXQUFXLENBQUM7QUFHaEIsUUFBTWlCLFFBQVF6QixRQUFRLE1BQU07QUFDMUIsYUFBUzBCLGdCQUFnQkMsVUFBVUMsY0FBY3JCLFdBQVc7QUFDMUQsWUFBTXNCLGlCQUFpQixJQUFJYixJQUFJUixZQUFZRCxTQUFTLENBQUM7QUFDckRzQixxQkFBZUMsSUFBSUgsVUFBVUksU0FBU0gsY0FBYyxFQUFFLENBQUM7QUFFdkRiLHFCQUFnQmlCLFdBQVU7QUFBQSxRQUN4QixHQUFHQTtBQUFBQSxRQUNILENBQUN6QixTQUFTLEdBQUdzQjtBQUFBQSxNQUNmLEVBQUU7QUFBQSxJQUNKO0FBRUEsYUFBU0ksZUFBZTtBQUN0QixhQUFPO0FBQUEsUUFDTDdCLFVBQVU4QixPQUFPQyxZQUFZM0IsWUFBWUosUUFBUTtBQUFBLFFBQ2pEQyxTQUFTNkIsT0FBT0MsWUFBWTNCLFlBQVlILE9BQU87QUFBQSxRQUMvQ1k7QUFBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQSxhQUFTbUIsa0JBQWtCO0FBQ3pCQyxjQUFRQyxJQUFJLGtCQUFrQjtBQUc5QnZCLHFCQUFlO0FBQUEsUUFDYlgsVUFBVSxvQkFBSVksSUFBSTtBQUFBLFFBQ2xCWCxTQUFTLG9CQUFJVyxJQUFJO0FBQUEsTUFDbkIsQ0FBQztBQUdERSxnQkFBVTtBQUFBLFFBQUVkLFVBQVU7QUFBQSxRQUFHQyxTQUFTO0FBQUEsUUFBR2MsT0FBTztBQUFBLE1BQUUsQ0FBQztBQUcvQ0Usb0JBQWMsR0FBSTtBQUdsQmtCLGlCQUFXLE1BQU07QUFDZkYsZ0JBQVFDLElBQUkscUJBQXFCO0FBQUEsTUFDbkMsR0FBRyxFQUFFO0FBQUEsSUFDUDtBQUNBLGFBQVNFLGFBQWFDLFFBQVE7QUFDNUJwQixvQkFBZVcsVUFBUztBQUN0QixjQUFNVSxnQkFBZ0JDLE9BQU9YLElBQUksS0FBSztBQUN0QyxjQUFNWSxjQUFjRCxPQUFPRixNQUFNLEtBQUs7QUFDdEMsZUFBT0ksS0FBS0MsSUFBSSxHQUFHSixnQkFBZ0JFLFdBQVc7QUFBQSxNQUNoRCxDQUFDO0FBQUEsSUFDSDtBQUVBLFdBQU8sQ0FDTDtBQUFBLE1BQ0V4QyxVQUFVSSxZQUFZSjtBQUFBQSxNQUN0QkMsU0FBU0csWUFBWUg7QUFBQUEsTUFDckJZO0FBQUFBLE1BQ0FHO0FBQUFBLElBQ0YsR0FDQU0saUJBQ0FVLGlCQUNBSSxjQUNBUCxZQUFZO0FBQUEsRUFFaEIsR0FBRyxDQUFDekIsYUFBYVMsUUFBUUcsVUFBVSxDQUFDO0FBRXBDLFNBQU8sdUJBQUMsYUFBYSxVQUFiLEVBQXNCLE9BQWMsR0FBSVAsU0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUErQztBQUN4RDtBQUFDQyxHQS9GZUYsc0JBQW9CO0FBQUFtQyxLQUFwQm5DO0FBQW9CLElBQUFtQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiY3JlYXRlQ29udGV4dCIsInVzZVN0YXRlIiwidXNlTWVtbyIsInVzZUVmZmVjdCIsIk9yZGVyQ29udGV4dCIsInByaWNlUGVySXRlbSIsInByb2R1Y3RzIiwib3B0aW9ucyIsImNhbGN1bGF0ZVN1YnRvdGFsIiwib3JkZXJUeXBlIiwib3JkZXJDb3VudHMiLCJvcHRpb25Db3VudCIsImNvdW50IiwidmFsdWVzIiwiT3JkZXJDb250ZXh0UHJvdmlkZXIiLCJwcm9wcyIsIl9zIiwic2V0T3JkZXJDb3VudHMiLCJNYXAiLCJ0b3RhbHMiLCJzZXRUb3RhbHMiLCJ0b3RhbCIsInVzZXJQb2ludHMiLCJzZXRVc2VyUG9pbnRzIiwic2l6ZSIsInByb2R1Y3RzVG90YWwiLCJvcHRpb25zVG90YWwiLCJ2YWx1ZSIsInVwZGF0ZUl0ZW1Db3VudCIsIml0ZW1OYW1lIiwibmV3SXRlbUNvdW50IiwibmV3T3JkZXJDb3VudHMiLCJzZXQiLCJwYXJzZUludCIsInByZXYiLCJnZXRPcmRlckRhdGEiLCJPYmplY3QiLCJmcm9tRW50cmllcyIsInJlc2V0T3JkZXJEYXRhcyIsImNvbnNvbGUiLCJsb2ciLCJzZXRUaW1lb3V0IiwiZGVkdWN0UG9pbnRzIiwiYW1vdW50IiwiY3VycmVudFBvaW50cyIsIk51bWJlciIsInZhbGlkQW1vdW50IiwiTWF0aCIsIm1heCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiT3JkZXJDb250ZXh0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VTdGF0ZSwgdXNlTWVtbywgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5cbi8vIE9yZGVyQ29udGV4dCDsg53shLFcbmV4cG9ydCBjb25zdCBPcmRlckNvbnRleHQgPSBjcmVhdGVDb250ZXh0KCk7XG5cbi8vIOqwgSDslYTsnbTthZzsnZgg64uo7JyEIOqwgOqyqeydhCDsoJXsnZhcbmNvbnN0IHByaWNlUGVySXRlbSA9IHtcbiAgcHJvZHVjdHM6IDEwMDAsXG4gIG9wdGlvbnM6IDUwMCxcbn07XG5cbi8vIOyjvOyWtOynhCDtg4DsnoXsnZgg7IaM6rOE66W8IOqzhOyCsO2VmOuKlCDtlajsiJhcbmZ1bmN0aW9uIGNhbGN1bGF0ZVN1YnRvdGFsKG9yZGVyVHlwZSwgb3JkZXJDb3VudHMpIHtcbiAgbGV0IG9wdGlvbkNvdW50ID0gMDtcbiAgZm9yIChjb25zdCBjb3VudCBvZiBvcmRlckNvdW50c1tvcmRlclR5cGVdLnZhbHVlcygpKSB7XG4gICAgb3B0aW9uQ291bnQgKz0gY291bnQ7XG4gIH1cbiAgcmV0dXJuIG9wdGlvbkNvdW50ICogcHJpY2VQZXJJdGVtW29yZGVyVHlwZV07XG59XG5cbi8vIOy7qO2FjeyKpO2KuCBQcm92aWRlciDsu7Ttj6zrhIztirhcbmV4cG9ydCBmdW5jdGlvbiBPcmRlckNvbnRleHRQcm92aWRlcihwcm9wcykge1xuICAvLyDso7zrrLgg7IiY65+J7J2EIOq0gOumrO2VmOuKlCDsg4Htg5xcbiAgY29uc3QgW29yZGVyQ291bnRzLCBzZXRPcmRlckNvdW50c10gPSB1c2VTdGF0ZSh7XG4gICAgcHJvZHVjdHM6IG5ldyBNYXAoKSxcbiAgICBvcHRpb25zOiBuZXcgTWFwKCksXG4gIH0pO1xuXG4gIC8vIOy0nSDquIjslaHsnYQg6rSA66as7ZWY64qUIOyDge2DnFxuICBjb25zdCBbdG90YWxzLCBzZXRUb3RhbHNdID0gdXNlU3RhdGUoe1xuICAgIHByb2R1Y3RzOiAwLFxuICAgIG9wdGlvbnM6IDAsXG4gICAgdG90YWw6IDAsXG4gIH0pO1xuXG4gIC8vIOKchSDsgqzsmqnsnpAg7Y+s7J247Yq4IOy0iOq4sOqwkiDshKTsoJVcbiAgY29uc3QgW3VzZXJQb2ludHMsIHNldFVzZXJQb2ludHNdID0gdXNlU3RhdGUoNTAwMCk7XG5cbiAgLy8g4pyFIOyjvOusuCDsiJjrn4nsnbQg67OA6rK965CgIOuVjCDstJ0g6riI7JWh7J2EIOuLpOyLnCDqs4TsgrDtlZjripQgdXNlRWZmZWN0XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKG9yZGVyQ291bnRzLnByb2R1Y3RzLnNpemUgPT09IDAgJiYgb3JkZXJDb3VudHMub3B0aW9ucy5zaXplID09PSAwKSB7XG4gICAgICBzZXRUb3RhbHMoeyBwcm9kdWN0czogMCwgb3B0aW9uczogMCwgdG90YWw6IDAgfSk7IC8vIPCfm6Ag7KO866y4IOy0iOq4sO2ZlCDsi5wg7KaJ7IucIDDsnLzroZwg7ISk7KCVXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHByb2R1Y3RzVG90YWwgPSBjYWxjdWxhdGVTdWJ0b3RhbChcInByb2R1Y3RzXCIsIG9yZGVyQ291bnRzKTtcbiAgICAgIGNvbnN0IG9wdGlvbnNUb3RhbCA9IGNhbGN1bGF0ZVN1YnRvdGFsKFwib3B0aW9uc1wiLCBvcmRlckNvdW50cyk7XG4gICAgICBzZXRUb3RhbHMoe1xuICAgICAgICBwcm9kdWN0czogcHJvZHVjdHNUb3RhbCxcbiAgICAgICAgb3B0aW9uczogb3B0aW9uc1RvdGFsLFxuICAgICAgICB0b3RhbDogcHJvZHVjdHNUb3RhbCArIG9wdGlvbnNUb3RhbCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwgW29yZGVyQ291bnRzXSk7IC8vIOKshSBvcmRlckNvdW50cyDrs4Dqsr3rkKAg65WM66eI64ukIOyLpO2WiVxuXG4gIC8vIENvbnRleHTsl5DshJwg6rO17Jyg7ZWgIOqwklxuICBjb25zdCB2YWx1ZSA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGZ1bmN0aW9uIHVwZGF0ZUl0ZW1Db3VudChpdGVtTmFtZSwgbmV3SXRlbUNvdW50LCBvcmRlclR5cGUpIHtcbiAgICAgIGNvbnN0IG5ld09yZGVyQ291bnRzID0gbmV3IE1hcChvcmRlckNvdW50c1tvcmRlclR5cGVdKTtcbiAgICAgIG5ld09yZGVyQ291bnRzLnNldChpdGVtTmFtZSwgcGFyc2VJbnQobmV3SXRlbUNvdW50LCAxMCkpO1xuXG4gICAgICBzZXRPcmRlckNvdW50cygocHJldikgPT4gKHtcbiAgICAgICAgLi4ucHJldixcbiAgICAgICAgW29yZGVyVHlwZV06IG5ld09yZGVyQ291bnRzLFxuICAgICAgfSkpO1xuICAgIH1cblxuICAgIGZ1bmN0aW9uIGdldE9yZGVyRGF0YSgpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHByb2R1Y3RzOiBPYmplY3QuZnJvbUVudHJpZXMob3JkZXJDb3VudHMucHJvZHVjdHMpLFxuICAgICAgICBvcHRpb25zOiBPYmplY3QuZnJvbUVudHJpZXMob3JkZXJDb3VudHMub3B0aW9ucyksXG4gICAgICAgIHRvdGFscyxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gcmVzZXRPcmRlckRhdGFzKCkge1xuICAgICAgY29uc29sZS5sb2coXCLwn5ugIOyjvOusuCDrjbDsnbTthLAg7LSI6riw7ZmUIOyLnOyekVwiKTtcblxuICAgICAgLy8g4pyFIOyjvOusuCDsiJjrn4nsnYQg66i87KCAIOy0iOq4sO2ZlFxuICAgICAgc2V0T3JkZXJDb3VudHMoe1xuICAgICAgICBwcm9kdWN0czogbmV3IE1hcCgpLFxuICAgICAgICBvcHRpb25zOiBuZXcgTWFwKCksXG4gICAgICB9KTtcblxuICAgICAgLy8g4pyFIOy0nSDqsIDqsqnrj4Qg7KaJ7IucIDDsnLzroZwg7ISk7KCVXG4gICAgICBzZXRUb3RhbHMoeyBwcm9kdWN0czogMCwgb3B0aW9uczogMCwgdG90YWw6IDAgfSk7XG5cbiAgICAgIC8vIOKchSDtj6zsnbjtirgg7LSI6riw7ZmUXG4gICAgICBzZXRVc2VyUG9pbnRzKDUwMDApO1xuXG4gICAgICAvLyDinIUg7IOB7YOcIOyXheuNsOydtO2KuCDtm4Qg6rCV7KCcIOumrOugjOuNlOungSDtirjrpqzqsbBcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhcIvCflIQg7KO866y4IOuNsOydtO2EsCDsmYTsoIQg7LSI6riw7ZmUIOyZhOujjFwiKTtcbiAgICAgIH0sIDUwKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZGVkdWN0UG9pbnRzKGFtb3VudCkge1xuICAgICAgc2V0VXNlclBvaW50cygocHJldikgPT4ge1xuICAgICAgICBjb25zdCBjdXJyZW50UG9pbnRzID0gTnVtYmVyKHByZXYpIHx8IDUwMDA7XG4gICAgICAgIGNvbnN0IHZhbGlkQW1vdW50ID0gTnVtYmVyKGFtb3VudCkgfHwgMDtcbiAgICAgICAgcmV0dXJuIE1hdGgubWF4KDAsIGN1cnJlbnRQb2ludHMgLSB2YWxpZEFtb3VudCk7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICByZXR1cm4gW1xuICAgICAge1xuICAgICAgICBwcm9kdWN0czogb3JkZXJDb3VudHMucHJvZHVjdHMsXG4gICAgICAgIG9wdGlvbnM6IG9yZGVyQ291bnRzLm9wdGlvbnMsXG4gICAgICAgIHRvdGFscyxcbiAgICAgICAgdXNlclBvaW50cyxcbiAgICAgIH0sXG4gICAgICB1cGRhdGVJdGVtQ291bnQsXG4gICAgICByZXNldE9yZGVyRGF0YXMsXG4gICAgICBkZWR1Y3RQb2ludHMsXG4gICAgICBnZXRPcmRlckRhdGEsXG4gICAgXTtcbiAgfSwgW29yZGVyQ291bnRzLCB0b3RhbHMsIHVzZXJQb2ludHNdKTtcblxuICByZXR1cm4gPE9yZGVyQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17dmFsdWV9IHsuLi5wcm9wc30gLz47XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qaWh5ZW9uL1dlYnN0b3JtUHJvamVjdHMvcmVhY3QtdGVzdC1zaG9wL3JlYWN0LXNob3Atdml0ZS10ZGQtY2xpZW50L3NyYy9jb250ZXh0cy9PcmRlckNvbnRleHQuanN4In0=