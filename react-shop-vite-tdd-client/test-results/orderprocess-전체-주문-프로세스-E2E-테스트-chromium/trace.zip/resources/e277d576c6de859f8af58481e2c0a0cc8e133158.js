import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/OrderPage/Options.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=73008799"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Options.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=73008799"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
function Options({
  name,
  updateItemCount
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "form-check", children: [
    /* @__PURE__ */ jsxDEV("input", { type: "checkbox", className: "form-check-input", id: `${name}-option`, onChange: (event) => {
      updateItemCount(name, event.target.checked ? 1 : 0);
    } }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Options.jsx",
      lineNumber: 7,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("label", { className: "form-check-label ms-2", htmlFor: `${name}-option`, children: name }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Options.jsx",
      lineNumber: 10,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Options.jsx",
    lineNumber: 6,
    columnNumber: 10
  }, this);
}
_c = Options;
export default Options;
var _c;
$RefreshReg$(_c, "Options");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Options.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS1k7QUFMWixPQUFPQSxvQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFekIsU0FBU0MsUUFBUTtBQUFBLEVBQUVDO0FBQUFBLEVBQU1DO0FBQWdCLEdBQUc7QUFDeEMsU0FDSSx1QkFBQyxTQUFJLFdBQVUsY0FDWDtBQUFBLDJCQUFDLFdBQ0csTUFBSyxZQUNMLFdBQVUsb0JBQ1YsSUFBSyxHQUFFRCxJQUFLLFdBQ1osVUFBV0UsV0FBVTtBQUNqQkQsc0JBQWdCRCxNQUFNRSxNQUFNQyxPQUFPQyxVQUFVLElBQUksQ0FBQztBQUFBLElBQ3RELEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1NO0FBQUEsSUFFTix1QkFBQyxXQUFNLFdBQVUseUJBQXdCLFNBQVUsR0FBRUosSUFBSyxXQUNyREEsa0JBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBWUE7QUFFUjtBQUFDSyxLQWhCUU47QUFrQlQsZUFBZUE7QUFBUSxJQUFBTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJPcHRpb25zIiwibmFtZSIsInVwZGF0ZUl0ZW1Db3VudCIsImV2ZW50IiwidGFyZ2V0IiwiY2hlY2tlZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiT3B0aW9ucy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG5mdW5jdGlvbiBPcHRpb25zKHsgbmFtZSwgdXBkYXRlSXRlbUNvdW50IH0pIHtcbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tY2hlY2tcIj5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jaGVjay1pbnB1dFwiXG4gICAgICAgICAgICAgICAgaWQ9e2Ake25hbWV9LW9wdGlvbmB9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVJdGVtQ291bnQobmFtZSwgZXZlbnQudGFyZ2V0LmNoZWNrZWQgPyAxIDogMCk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1jaGVjay1sYWJlbCBtcy0yXCIgaHRtbEZvcj17YCR7bmFtZX0tb3B0aW9uYH0+XG4gICAgICAgICAgICAgICAge25hbWV9XG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBPcHRpb25zO1xuIl0sImZpbGUiOiIvVXNlcnMvamloeWVvbi9XZWJzdG9ybVByb2plY3RzL3JlYWN0LXRlc3Qtc2hvcC9yZWFjdC1zaG9wLXZpdGUtdGRkLWNsaWVudC9zcmMvcGFnZXMvT3JkZXJQYWdlL09wdGlvbnMuanN4In0=