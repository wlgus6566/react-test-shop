import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/contexts/WishlistContext.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=73008799"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/contexts/WishlistContext.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=73008799"; const createContext = __vite__cjsImport3_react["createContext"]; const useState = __vite__cjsImport3_react["useState"]; const useContext = __vite__cjsImport3_react["useContext"];
export const WishlistContext = createContext();
export function WishlistProvider({
  children,
  initialItems = []
}) {
  _s();
  const [wishlist, setWishlist] = useState(initialItems);
  const addToWishlist = (product) => {
    setWishlist((prev) => {
      if (!prev.some((item) => item.name === product.name)) {
        return [...prev, product];
      }
      return prev;
    });
  };
  const removeFromWishlist = (productName) => {
    setWishlist((prev) => prev.filter((item) => item.name !== productName));
  };
  const isInWishlist = (productName) => {
    return wishlist.some((item) => item.name === productName);
  };
  return /* @__PURE__ */ jsxDEV(WishlistContext.Provider, { value: {
    wishlist,
    addToWishlist,
    removeFromWishlist,
    isInWishlist
  }, children }, void 0, false, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/contexts/WishlistContext.jsx",
    lineNumber: 25,
    columnNumber: 10
  }, this);
}
_s(WishlistProvider, "Tcwzag26VncSzIgfmwhKFCv0Clc=");
_c = WishlistProvider;
export const useWishlist = () => {
  _s2();
  return useContext(WishlistContext);
};
_s2(useWishlist, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
$RefreshReg$(_c, "WishlistProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/contexts/WishlistContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQXpCUixTQUFTQSxlQUFlQyxVQUFVQyxrQkFBa0I7QUFFN0MsYUFBTUMsa0JBQWtCSCxjQUFjO0FBRXRDLGdCQUFTSSxpQkFBaUI7QUFBQSxFQUFFQztBQUFBQSxFQUFVQyxlQUFlO0FBQUcsR0FBRztBQUFBQyxLQUFBO0FBQzlELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJUixTQUFTSyxZQUFZO0FBRXJELFFBQU1JLGdCQUFpQkMsYUFBWTtBQUMvQkYsZ0JBQVlHLFVBQVE7QUFDaEIsVUFBSSxDQUFDQSxLQUFLQyxLQUFLQyxVQUFRQSxLQUFLQyxTQUFTSixRQUFRSSxJQUFJLEdBQUc7QUFDaEQsZUFBTyxDQUFDLEdBQUdILE1BQU1ELE9BQU87QUFBQSxNQUM1QjtBQUNBLGFBQU9DO0FBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0w7QUFFQSxRQUFNSSxxQkFBc0JDLGlCQUFnQjtBQUN4Q1IsZ0JBQVlHLFVBQVFBLEtBQUtNLE9BQU9KLFVBQVFBLEtBQUtDLFNBQVNFLFdBQVcsQ0FBQztBQUFBLEVBQ3RFO0FBRUEsUUFBTUUsZUFBZ0JGLGlCQUFnQjtBQUNsQyxXQUFPVCxTQUFTSyxLQUFLQyxVQUFRQSxLQUFLQyxTQUFTRSxXQUFXO0FBQUEsRUFDMUQ7QUFFQSxTQUNJLHVCQUFDLGdCQUFnQixVQUFoQixFQUF5QixPQUFPO0FBQUEsSUFDN0JUO0FBQUFBLElBQ0FFO0FBQUFBLElBQ0FNO0FBQUFBLElBQ0FHO0FBQUFBLEVBQ0osR0FDS2QsWUFOTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0E7QUFFUjtBQUFDRSxHQTlCZUgsa0JBQWdCO0FBQUFnQixLQUFoQmhCO0FBZ0NULGFBQU1pQixjQUFjQSxNQUFBO0FBQUFDLE1BQUE7QUFBQSxTQUFNcEIsV0FBV0MsZUFBZTtBQUFDO0FBQUNtQixJQUFoREQsYUFBVztBQUFBLElBQUFEO0FBQUFHLGFBQUFILElBQUEiLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlU3RhdGUiLCJ1c2VDb250ZXh0IiwiV2lzaGxpc3RDb250ZXh0IiwiV2lzaGxpc3RQcm92aWRlciIsImNoaWxkcmVuIiwiaW5pdGlhbEl0ZW1zIiwiX3MiLCJ3aXNobGlzdCIsInNldFdpc2hsaXN0IiwiYWRkVG9XaXNobGlzdCIsInByb2R1Y3QiLCJwcmV2Iiwic29tZSIsIml0ZW0iLCJuYW1lIiwicmVtb3ZlRnJvbVdpc2hsaXN0IiwicHJvZHVjdE5hbWUiLCJmaWx0ZXIiLCJpc0luV2lzaGxpc3QiLCJfYyIsInVzZVdpc2hsaXN0IiwiX3MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiV2lzaGxpc3RDb250ZXh0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VTdGF0ZSwgdXNlQ29udGV4dCB9IGZyb20gJ3JlYWN0JztcblxuZXhwb3J0IGNvbnN0IFdpc2hsaXN0Q29udGV4dCA9IGNyZWF0ZUNvbnRleHQoKTtcblxuZXhwb3J0IGZ1bmN0aW9uIFdpc2hsaXN0UHJvdmlkZXIoeyBjaGlsZHJlbiwgaW5pdGlhbEl0ZW1zID0gW10gfSkge1xuICAgIGNvbnN0IFt3aXNobGlzdCwgc2V0V2lzaGxpc3RdID0gdXNlU3RhdGUoaW5pdGlhbEl0ZW1zKTtcblxuICAgIGNvbnN0IGFkZFRvV2lzaGxpc3QgPSAocHJvZHVjdCkgPT4ge1xuICAgICAgICBzZXRXaXNobGlzdChwcmV2ID0+IHtcbiAgICAgICAgICAgIGlmICghcHJldi5zb21lKGl0ZW0gPT4gaXRlbS5uYW1lID09PSBwcm9kdWN0Lm5hbWUpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFsuLi5wcmV2LCBwcm9kdWN0XTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBwcmV2O1xuICAgICAgICB9KTtcbiAgICB9O1xuXG4gICAgY29uc3QgcmVtb3ZlRnJvbVdpc2hsaXN0ID0gKHByb2R1Y3ROYW1lKSA9PiB7XG4gICAgICAgIHNldFdpc2hsaXN0KHByZXYgPT4gcHJldi5maWx0ZXIoaXRlbSA9PiBpdGVtLm5hbWUgIT09IHByb2R1Y3ROYW1lKSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGlzSW5XaXNobGlzdCA9IChwcm9kdWN0TmFtZSkgPT4ge1xuICAgICAgICByZXR1cm4gd2lzaGxpc3Quc29tZShpdGVtID0+IGl0ZW0ubmFtZSA9PT0gcHJvZHVjdE5hbWUpO1xuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8V2lzaGxpc3RDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt7IFxuICAgICAgICAgICAgd2lzaGxpc3QsIFxuICAgICAgICAgICAgYWRkVG9XaXNobGlzdCwgXG4gICAgICAgICAgICByZW1vdmVGcm9tV2lzaGxpc3QsIFxuICAgICAgICAgICAgaXNJbldpc2hsaXN0IFxuICAgICAgICB9fT5cbiAgICAgICAgICAgIHtjaGlsZHJlbn1cbiAgICAgICAgPC9XaXNobGlzdENvbnRleHQuUHJvdmlkZXI+XG4gICAgKTtcbn1cblxuZXhwb3J0IGNvbnN0IHVzZVdpc2hsaXN0ID0gKCkgPT4gdXNlQ29udGV4dChXaXNobGlzdENvbnRleHQpOyAiXSwiZmlsZSI6Ii9Vc2Vycy9qaWh5ZW9uL1dlYnN0b3JtUHJvamVjdHMvcmVhY3QtdGVzdC1zaG9wL3JlYWN0LXNob3Atdml0ZS10ZGQtY2xpZW50L3NyYy9jb250ZXh0cy9XaXNobGlzdENvbnRleHQuanN4In0=