import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/OrderPage/style/OrderPage.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/style/OrderPage.css"
const __vite__css = ".type {\n    display: flex;\n    flex-wrap: wrap;\n    gap: 20px;\n}\n.type > div {\n    width: calc((100% - 40px) / 2);\n}\n.type input.form-number {\n    width: 100%;\n}"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))