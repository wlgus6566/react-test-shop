import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SummaryPage/SummaryPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=73008799"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=73008799"; const useState = __vite__cjsImport3_react["useState"]; const useContext = __vite__cjsImport3_react["useContext"];
import axios from "/node_modules/.vite/deps/axios.js?v=73008799";
import { OrderContext } from "/src/contexts/OrderContext.jsx";
import { processPayment } from "/src/utils/processPayment.js";
import "/src/pages/SummaryPage/SummaryPage.css";
const SummaryPage = ({
  setStep
}) => {
  _s();
  const [{
    totals,
    userPoints,
    products,
    options
  }, , , deductPoints, getOrderData] = useContext(OrderContext);
  const [checked, setChecked] = useState(false);
  const [usePoints, setUsePoints] = useState(false);
  const [usedPoints, setUsedPoints] = useState(0);
  const [error, setError] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const totalPrice = totals.total;
  const productList = Array.from(products.entries()).filter(([_, count]) => count > 0).map(([name, count]) => `${count} ${name}`).join(", ");
  const optionList = Array.from(options.entries()).filter(([_, count]) => count > 0).map(([name]) => name).join(", ");
  const handlePointsChange = (event) => {
    let value = parseInt(event.target.value, 10) || 0;
    if (value > userPoints) {
      setError("보유 포인트보다 많은 금액을 사용할 수 없습니다.");
    } else if (value > totalPrice) {
      setError("사용할 포인트가 결제 금액을 초과할 수 없습니다.");
    } else {
      setError(null);
    }
    setUsedPoints(value);
  };
  const handleSubmit = async (event) => {
    event.preventDefault();
    if (isSubmitting || error)
      return;
    setIsSubmitting(true);
    try {
      processPayment(userPoints, totalPrice, usePoints ? usedPoints : 0);
      deductPoints(usedPoints);
      const orderData = getOrderData();
      console.log("📌 전송할 데이터:", JSON.stringify(orderData, null, 2));
      const response = await axios.post("http://localhost:5003/order", orderData);
      console.log("✅ 주문 완료:", response.data);
      setStep(2);
    } catch (e) {
      setError(e.message);
    } finally {
      setTimeout(() => setIsSubmitting(false), 1e3);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "summary-container", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "summary-title", children: "주문 확인" }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
      lineNumber: 62,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("h2", { className: "summary-total", children: [
      "총 주문 금액: ",
      totalPrice.toLocaleString(),
      "원"
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
      lineNumber: 63,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("h3", { className: "summary-points", children: [
      "현재 보유 포인트: ",
      userPoints?.toLocaleString() ?? 0,
      "원"
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
      lineNumber: 64,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "selected-items mt-4", children: /* @__PURE__ */ jsxDEV("div", { className: "card mb-3", children: /* @__PURE__ */ jsxDEV("div", { className: "card-body", children: [
      /* @__PURE__ */ jsxDEV("h4", { className: "card-title", children: "선택한 항목" }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
        lineNumber: 70,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "selected-items-list", "data-testid": "selected-items", children: [
        /* @__PURE__ */ jsxDEV("div", { children: productList }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
          lineNumber: 72,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: optionList }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
          lineNumber: 73,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
        lineNumber: 71,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
      lineNumber: 69,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
      lineNumber: 68,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
      lineNumber: 67,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "checkbox-container", children: [
      /* @__PURE__ */ jsxDEV("input", { type: "checkbox", className: "form-check-input", checked: usePoints, onChange: (e) => {
        setUsePoints(e.target.checked);
        if (!e.target.checked) {
          setUsedPoints(0);
          setError(null);
        }
      }, id: "usePointsCheckbox" }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
        lineNumber: 80,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "usePointsCheckbox", children: "포인트 사용하기" }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
        lineNumber: 87,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
      lineNumber: 79,
      columnNumber: 13
    }, this),
    usePoints && /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "usedPointsInput", className: "form-label fw-bold", children: "사용할 포인트:" }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
        lineNumber: 91,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("input", { type: "number", id: "usedPointsInput", className: "point-input", value: usedPoints, onChange: handlePointsChange, min: "0", max: userPoints }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
        lineNumber: 92,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-muted", children: [
        "사용 가능 포인트: ",
        userPoints.toLocaleString(),
        "원"
      ] }, void 0, true, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
        lineNumber: 93,
        columnNumber: 21
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-message", children: error }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
        lineNumber: 94,
        columnNumber: 31
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
      lineNumber: 90,
      columnNumber: 27
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "mt-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "checkbox-container", children: [
        /* @__PURE__ */ jsxDEV("input", { type: "checkbox", className: "form-check-input", checked, onChange: (e) => setChecked(e.target.checked), id: "confirmCheckbox" }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
          lineNumber: 99,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "confirmCheckbox", children: "주문을 확인하셨나요?" }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
          lineNumber: 100,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
        lineNumber: 98,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { disabled: !checked || !!error, type: "submit", className: "submit-button mt-3", children: isSubmitting ? "결제 중..." : "결제하기" }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
        lineNumber: 103,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
      lineNumber: 97,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx",
    lineNumber: 61,
    columnNumber: 10
  }, this);
};
_s(SummaryPage, "7xkgwr4OGHpYzmzlUQryAXOpFDE=");
_c = SummaryPage;
export default SummaryPage;
var _c;
$RefreshReg$(_c, "SummaryPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/SummaryPage/SummaryPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUVZOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJFWixTQUFTQSxVQUFVQyxrQkFBa0I7QUFDckMsT0FBT0MsV0FBVztBQUNsQixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0Msc0JBQXNCO0FBQy9CLE9BQU87QUFHUCxNQUFNQyxjQUFjQSxDQUFDO0FBQUEsRUFBRUM7QUFBUSxNQUFNO0FBQUFDLEtBQUE7QUFDakMsUUFBTSxDQUFDO0FBQUEsSUFBRUM7QUFBQUEsSUFBUUM7QUFBQUEsSUFBWUM7QUFBQUEsSUFBVUM7QUFBQUEsRUFBUSxHQUFDLElBQU1DLGNBQWNDLFlBQVksSUFBSVosV0FBV0UsWUFBWTtBQUMzRyxRQUFNLENBQUNXLFNBQVNDLFVBQVUsSUFBSWYsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ2dCLFdBQVdDLFlBQVksSUFBSWpCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNrQixZQUFZQyxhQUFhLElBQUluQixTQUFTLENBQUM7QUFDOUMsUUFBTSxDQUFDb0IsT0FBT0MsUUFBUSxJQUFJckIsU0FBUyxJQUFJO0FBQ3ZDLFFBQU0sQ0FBQ3NCLGNBQWNDLGVBQWUsSUFBSXZCLFNBQVMsS0FBSztBQUV0RCxRQUFNd0IsYUFBYWhCLE9BQU9pQjtBQUcxQixRQUFNQyxjQUFjQyxNQUFNQyxLQUFLbEIsU0FBU21CLFFBQVEsQ0FBQyxFQUM1Q0MsT0FBTyxDQUFDLENBQUNDLEdBQUdDLEtBQUssTUFBTUEsUUFBUSxDQUFDLEVBQ2hDQyxJQUFJLENBQUMsQ0FBQ0MsTUFBTUYsS0FBSyxNQUFPLEdBQUVBLEtBQU0sSUFBR0UsSUFBSyxFQUFDLEVBQ3pDQyxLQUFLLElBQUk7QUFHZCxRQUFNQyxhQUFhVCxNQUFNQyxLQUFLakIsUUFBUWtCLFFBQVEsQ0FBQyxFQUMxQ0MsT0FBTyxDQUFDLENBQUNDLEdBQUdDLEtBQUssTUFBTUEsUUFBUSxDQUFDLEVBQ2hDQyxJQUFJLENBQUMsQ0FBQ0MsSUFBSSxNQUFNQSxJQUFJLEVBQ3BCQyxLQUFLLElBQUk7QUFHZCxRQUFNRSxxQkFBc0JDLFdBQVU7QUFDbEMsUUFBSUMsUUFBUUMsU0FBU0YsTUFBTUcsT0FBT0YsT0FBTyxFQUFFLEtBQUs7QUFFaEQsUUFBSUEsUUFBUTlCLFlBQVk7QUFDcEJZLGVBQVMsNkJBQTZCO0FBQUEsSUFDMUMsV0FBV2tCLFFBQVFmLFlBQVk7QUFDM0JILGVBQVMsNkJBQTZCO0FBQUEsSUFDMUMsT0FBTztBQUNIQSxlQUFTLElBQUk7QUFBQSxJQUNqQjtBQUVBRixrQkFBY29CLEtBQUs7QUFBQSxFQUN2QjtBQUVBLFFBQU1HLGVBQWUsT0FBT0osVUFBVTtBQUNsQ0EsVUFBTUssZUFBZTtBQUNyQixRQUFJckIsZ0JBQWdCRjtBQUFPO0FBQzNCRyxvQkFBZ0IsSUFBSTtBQUVwQixRQUFJO0FBQ0FuQixxQkFBZUssWUFBWWUsWUFBWVIsWUFBWUUsYUFBYSxDQUFDO0FBQ2pFTixtQkFBYU0sVUFBVTtBQUV2QixZQUFNMEIsWUFBWS9CLGFBQWE7QUFDL0JnQyxjQUFRQyxJQUFJLGVBQWVDLEtBQUtDLFVBQVVKLFdBQVcsTUFBTSxDQUFDLENBQUM7QUFFN0QsWUFBTUssV0FBVyxNQUFNL0MsTUFBTWdELEtBQUssK0JBQStCTixTQUFTO0FBQzFFQyxjQUFRQyxJQUFJLFlBQVlHLFNBQVNFLElBQUk7QUFFckM3QyxjQUFRLENBQUM7QUFBQSxJQUNiLFNBQVM4QyxHQUFHO0FBQ1IvQixlQUFTK0IsRUFBRUMsT0FBTztBQUFBLElBQ3RCLFVBQUM7QUFDR0MsaUJBQVcsTUFBTS9CLGdCQUFnQixLQUFLLEdBQUcsR0FBSTtBQUFBLElBQ2pEO0FBQUEsRUFDSjtBQUVBLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLHFCQUNYO0FBQUEsMkJBQUMsUUFBRyxXQUFVLGlCQUFnQixxQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQztBQUFBLElBQ25DLHVCQUFDLFFBQUcsV0FBVSxpQkFBZ0I7QUFBQTtBQUFBLE1BQVVDLFdBQVcrQixlQUFlO0FBQUEsTUFBRTtBQUFBLFNBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUU7QUFBQSxJQUNyRSx1QkFBQyxRQUFHLFdBQVUsa0JBQWlCO0FBQUE7QUFBQSxNQUFZOUMsWUFBWThDLGVBQWUsS0FBSztBQUFBLE1BQUU7QUFBQSxTQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThFO0FBQUEsSUFHOUUsdUJBQUMsU0FBSSxXQUFVLHVCQUNYLGlDQUFDLFNBQUksV0FBVSxhQUNYLGlDQUFDLFNBQUksV0FBVSxhQUNYO0FBQUEsNkJBQUMsUUFBRyxXQUFVLGNBQWEsc0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUNqQyx1QkFBQyxTQUFJLFdBQVUsdUJBQXNCLGVBQVksa0JBQzdDO0FBQUEsK0JBQUMsU0FBSzdCLHlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQSxRQUNsQix1QkFBQyxTQUFLVSx3QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlCO0FBQUEsV0FGckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUEsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUEsS0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxzQkFDWDtBQUFBLDZCQUFDLFdBQ0csTUFBSyxZQUNMLFdBQVUsb0JBQ1YsU0FBU3BCLFdBQ1QsVUFBV29DLE9BQU07QUFDYm5DLHFCQUFhbUMsRUFBRVgsT0FBTzNCLE9BQU87QUFDN0IsWUFBSSxDQUFDc0MsRUFBRVgsT0FBTzNCLFNBQVM7QUFDbkJLLHdCQUFjLENBQUM7QUFDZkUsbUJBQVMsSUFBSTtBQUFBLFFBQ2pCO0FBQUEsTUFDSixHQUNBLElBQUcsdUJBWFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVcwQjtBQUFBLE1BRTFCLHVCQUFDLFdBQU0sU0FBUSxxQkFBb0Isd0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkM7QUFBQSxTQWQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxJQUVDTCxhQUNHLHVCQUFDLFNBQUksV0FBVSxRQUNYO0FBQUEsNkJBQUMsV0FBTSxTQUFRLG1CQUFrQixXQUFVLHNCQUFxQix3QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RTtBQUFBLE1BQ3hFLHVCQUFDLFdBQ0csTUFBSyxVQUNMLElBQUcsbUJBQ0gsV0FBVSxlQUNWLE9BQU9FLFlBQ1AsVUFBVW1CLG9CQUNWLEtBQUksS0FDSixLQUFLNUIsY0FQVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT29CO0FBQUEsTUFFcEIsdUJBQUMsT0FBRSxXQUFVLGNBQWE7QUFBQTtBQUFBLFFBQVlBLFdBQVc4QyxlQUFlO0FBQUEsUUFBRTtBQUFBLFdBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUU7QUFBQSxNQUNsRW5DLFNBQVMsdUJBQUMsT0FBRSxXQUFVLGlCQUFpQkEsbUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0M7QUFBQSxTQVpsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxJQUdKLHVCQUFDLFVBQUssVUFBVXNCLGNBQWMsV0FBVSxRQUNwQztBQUFBLDZCQUFDLFNBQUksV0FBVSxzQkFDWDtBQUFBLCtCQUFDLFdBQ0csTUFBSyxZQUNMLFdBQVUsb0JBQ1YsU0FDQSxVQUFXVSxPQUFNckMsV0FBV3FDLEVBQUVYLE9BQU8zQixPQUFPLEdBQzVDLElBQUcscUJBTFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUt3QjtBQUFBLFFBRXhCLHVCQUFDLFdBQU0sU0FBUSxtQkFBa0IsMkJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEM7QUFBQSxXQVJoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVBLHVCQUFDLFlBQ0csVUFBVSxDQUFDQSxXQUFXLENBQUMsQ0FBQ00sT0FDeEIsTUFBSyxVQUNMLFdBQVUsc0JBRVRFLHlCQUFlLFlBQVksVUFMaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsU0FsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLE9BdkVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3RUE7QUFHUjtBQUFFZixHQXhJSUYsYUFBVztBQUFBbUQsS0FBWG5EO0FBMElOLGVBQWVBO0FBQVksSUFBQW1EO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUNvbnRleHQiLCJheGlvcyIsIk9yZGVyQ29udGV4dCIsInByb2Nlc3NQYXltZW50IiwiU3VtbWFyeVBhZ2UiLCJzZXRTdGVwIiwiX3MiLCJ0b3RhbHMiLCJ1c2VyUG9pbnRzIiwicHJvZHVjdHMiLCJvcHRpb25zIiwiZGVkdWN0UG9pbnRzIiwiZ2V0T3JkZXJEYXRhIiwiY2hlY2tlZCIsInNldENoZWNrZWQiLCJ1c2VQb2ludHMiLCJzZXRVc2VQb2ludHMiLCJ1c2VkUG9pbnRzIiwic2V0VXNlZFBvaW50cyIsImVycm9yIiwic2V0RXJyb3IiLCJpc1N1Ym1pdHRpbmciLCJzZXRJc1N1Ym1pdHRpbmciLCJ0b3RhbFByaWNlIiwidG90YWwiLCJwcm9kdWN0TGlzdCIsIkFycmF5IiwiZnJvbSIsImVudHJpZXMiLCJmaWx0ZXIiLCJfIiwiY291bnQiLCJtYXAiLCJuYW1lIiwiam9pbiIsIm9wdGlvbkxpc3QiLCJoYW5kbGVQb2ludHNDaGFuZ2UiLCJldmVudCIsInZhbHVlIiwicGFyc2VJbnQiLCJ0YXJnZXQiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsIm9yZGVyRGF0YSIsImNvbnNvbGUiLCJsb2ciLCJKU09OIiwic3RyaW5naWZ5IiwicmVzcG9uc2UiLCJwb3N0IiwiZGF0YSIsImUiLCJtZXNzYWdlIiwic2V0VGltZW91dCIsInRvTG9jYWxlU3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTdW1tYXJ5UGFnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUNvbnRleHQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcbmltcG9ydCB7IE9yZGVyQ29udGV4dCB9IGZyb20gXCIuLi8uLi9jb250ZXh0cy9PcmRlckNvbnRleHRcIjtcbmltcG9ydCB7IHByb2Nlc3NQYXltZW50IH0gZnJvbSBcIi4uLy4uL3V0aWxzL3Byb2Nlc3NQYXltZW50XCI7XG5pbXBvcnQgXCIuL1N1bW1hcnlQYWdlLmNzc1wiO1xuXG5cbmNvbnN0IFN1bW1hcnlQYWdlID0gKHsgc2V0U3RlcCB9KSA9PiB7XG4gICAgY29uc3QgW3sgdG90YWxzLCB1c2VyUG9pbnRzLCBwcm9kdWN0cywgb3B0aW9ucyB9LCAsICwgZGVkdWN0UG9pbnRzLCBnZXRPcmRlckRhdGFdID0gdXNlQ29udGV4dChPcmRlckNvbnRleHQpO1xuICAgIGNvbnN0IFtjaGVja2VkLCBzZXRDaGVja2VkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbdXNlUG9pbnRzLCBzZXRVc2VQb2ludHNdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFt1c2VkUG9pbnRzLCBzZXRVc2VkUG9pbnRzXSA9IHVzZVN0YXRlKDApO1xuICAgIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW2lzU3VibWl0dGluZywgc2V0SXNTdWJtaXR0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIGNvbnN0IHRvdGFsUHJpY2UgPSB0b3RhbHMudG90YWw7XG5cbiAgICAvLyDshKDtg53tlZwg7IOB7ZKIIOuqqeuhnSDsg53shLFcbiAgICBjb25zdCBwcm9kdWN0TGlzdCA9IEFycmF5LmZyb20ocHJvZHVjdHMuZW50cmllcygpKVxuICAgICAgICAuZmlsdGVyKChbXywgY291bnRdKSA9PiBjb3VudCA+IDApXG4gICAgICAgIC5tYXAoKFtuYW1lLCBjb3VudF0pID0+IGAke2NvdW50fSAke25hbWV9YClcbiAgICAgICAgLmpvaW4oXCIsIFwiKTtcblxuICAgIC8vIOyEoO2Dne2VnCDsmLXshZgg66qp66GdIOyDneyEsVxuICAgIGNvbnN0IG9wdGlvbkxpc3QgPSBBcnJheS5mcm9tKG9wdGlvbnMuZW50cmllcygpKVxuICAgICAgICAuZmlsdGVyKChbXywgY291bnRdKSA9PiBjb3VudCA+IDApXG4gICAgICAgIC5tYXAoKFtuYW1lXSkgPT4gbmFtZSlcbiAgICAgICAgLmpvaW4oXCIsIFwiKTtcblxuICAgIC8vIOKchSDtj6zsnbjtirgg7J6F66ClIOyLnCDsi6Tsi5zqsIQg7Jyg7Zqo7ISxIOqygOyCrFxuICAgIGNvbnN0IGhhbmRsZVBvaW50c0NoYW5nZSA9IChldmVudCkgPT4ge1xuICAgICAgICBsZXQgdmFsdWUgPSBwYXJzZUludChldmVudC50YXJnZXQudmFsdWUsIDEwKSB8fCAwO1xuXG4gICAgICAgIGlmICh2YWx1ZSA+IHVzZXJQb2ludHMpIHtcbiAgICAgICAgICAgIHNldEVycm9yKFwi67O07JygIO2PrOyduO2KuOuztOuLpCDrp47snYAg6riI7JWh7J2EIOyCrOyaqe2VoCDsiJgg7JeG7Iq164uI64ukLlwiKTtcbiAgICAgICAgfSBlbHNlIGlmICh2YWx1ZSA+IHRvdGFsUHJpY2UpIHtcbiAgICAgICAgICAgIHNldEVycm9yKFwi7IKs7Jqp7ZWgIO2PrOyduO2KuOqwgCDqsrDsoJwg6riI7JWh7J2EIOy0iOqzvO2VoCDsiJgg7JeG7Iq164uI64ukLlwiKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldEVycm9yKG51bGwpOyAvLyDsmKzrsJTrpbgg6rCSIOyeheugpSDsi5wg7JeQ65+sIOygnOqxsFxuICAgICAgICB9XG5cbiAgICAgICAgc2V0VXNlZFBvaW50cyh2YWx1ZSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBpZiAoaXNTdWJtaXR0aW5nIHx8IGVycm9yKSByZXR1cm47IC8vIOKchSDsl5Drn6zqsIAg7J6I7Jy866m0IOqysOygnCDrtojqsIBcbiAgICAgICAgc2V0SXNTdWJtaXR0aW5nKHRydWUpO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBwcm9jZXNzUGF5bWVudCh1c2VyUG9pbnRzLCB0b3RhbFByaWNlLCB1c2VQb2ludHMgPyB1c2VkUG9pbnRzIDogMCk7XG4gICAgICAgICAgICBkZWR1Y3RQb2ludHModXNlZFBvaW50cyk7XG5cbiAgICAgICAgICAgIGNvbnN0IG9yZGVyRGF0YSA9IGdldE9yZGVyRGF0YSgpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCLwn5OMIOyghOyGoe2VoCDrjbDsnbTthLA6XCIsIEpTT04uc3RyaW5naWZ5KG9yZGVyRGF0YSwgbnVsbCwgMikpO1xuXG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGF4aW9zLnBvc3QoXCJodHRwOi8vbG9jYWxob3N0OjUwMDMvb3JkZXJcIiwgb3JkZXJEYXRhKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi4pyFIOyjvOusuCDsmYTro4w6XCIsIHJlc3BvbnNlLmRhdGEpO1xuXG4gICAgICAgICAgICBzZXRTdGVwKDIpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBzZXRFcnJvcihlLm1lc3NhZ2UpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpLCAxMDAwKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktY29udGFpbmVyXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwic3VtbWFyeS10aXRsZVwiPuyjvOusuCDtmZXsnbg8L2gxPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInN1bW1hcnktdG90YWxcIj7stJ0g7KO866y4IOq4iOyVoToge3RvdGFsUHJpY2UudG9Mb2NhbGVTdHJpbmcoKX3sm5A8L2gyPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInN1bW1hcnktcG9pbnRzXCI+7ZiE7J6sIOuztOycoCDtj6zsnbjtirg6IHt1c2VyUG9pbnRzPy50b0xvY2FsZVN0cmluZygpID8/IDB97JuQPC9oMz5cblxuICAgICAgICAgICAgey8qIOyEoO2Dne2VnCDsg4Htkojqs7wg7Ji17IWYIOuqqeuhnSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VsZWN0ZWQtaXRlbXMgbXQtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBtYi0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiY2FyZC10aXRsZVwiPuyEoO2Dne2VnCDtla3rqqk8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWxlY3RlZC1pdGVtcy1saXN0XCIgZGF0YS10ZXN0aWQ9XCJzZWxlY3RlZC1pdGVtc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+e3Byb2R1Y3RMaXN0fTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+e29wdGlvbkxpc3R9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjaGVja2JveC1jb250YWluZXJcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jaGVjay1pbnB1dFwiXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VzZVBvaW50c31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRVc2VQb2ludHMoZS50YXJnZXQuY2hlY2tlZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWUudGFyZ2V0LmNoZWNrZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRVc2VkUG9pbnRzKDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9yKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICBpZD1cInVzZVBvaW50c0NoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwidXNlUG9pbnRzQ2hlY2tib3hcIj7tj6zsnbjtirgg7IKs7Jqp7ZWY6riwPC9sYWJlbD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7dXNlUG9pbnRzICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJ1c2VkUG9pbnRzSW5wdXRcIiBjbGFzc05hbWU9XCJmb3JtLWxhYmVsIGZ3LWJvbGRcIj7sgqzsmqntlaAg7Y+s7J247Yq4OjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInVzZWRQb2ludHNJbnB1dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwb2ludC1pbnB1dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXNlZFBvaW50c31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQb2ludHNDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heD17dXNlclBvaW50c31cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1tdXRlZFwiPuyCrOyaqSDqsIDriqUg7Y+s7J247Yq4OiB7dXNlclBvaW50cy50b0xvY2FsZVN0cmluZygpfeybkDwvcD5cbiAgICAgICAgICAgICAgICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImVycm9yLW1lc3NhZ2VcIj57ZXJyb3J9PC9wPn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cIm10LTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNoZWNrYm94LWNvbnRhaW5lclwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNoZWNrLWlucHV0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2NoZWNrZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENoZWNrZWQoZS50YXJnZXQuY2hlY2tlZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNvbmZpcm1DaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiY29uZmlybUNoZWNrYm94XCI+7KO866y47J2EIO2ZleyduO2VmOyFqOuCmOyalD88L2xhYmVsPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWNoZWNrZWQgfHwgISFlcnJvcn1cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInN1Ym1pdC1idXR0b24gbXQtM1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7aXNTdWJtaXR0aW5nID8gXCLqsrDsoJwg7KSRLi4uXCIgOiBcIuqysOygnO2VmOq4sFwifVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xuXG59O1xuXG5leHBvcnQgZGVmYXVsdCBTdW1tYXJ5UGFnZTtcbiJdLCJmaWxlIjoiL1VzZXJzL2ppaHllb24vV2Vic3Rvcm1Qcm9qZWN0cy9yZWFjdC10ZXN0LXNob3AvcmVhY3Qtc2hvcC12aXRlLXRkZC1jbGllbnQvc3JjL3BhZ2VzL1N1bW1hcnlQYWdlL1N1bW1hcnlQYWdlLmpzeCJ9