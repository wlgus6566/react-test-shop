import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/OrderPage/OrderPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=73008799"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/OrderPage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=73008799"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useContext = __vite__cjsImport3_react["useContext"];
import { OrderContext } from "/src/contexts/OrderContext.jsx";
import Type from "/src/pages/OrderPage/Type.jsx?t=1741328329799";
function OrderPage({
  setStep
}) {
  _s();
  const [{
    totals
  }] = useContext(OrderContext);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-center mb-4", children: "🛫 여행 상품  주문" }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/OrderPage.jsx",
      lineNumber: 13,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "row", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "col-md-6", children: /* @__PURE__ */ jsxDEV(Type, { orderType: "products" }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/OrderPage.jsx",
        lineNumber: 16,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/OrderPage.jsx",
        lineNumber: 15,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "col-md-6", children: /* @__PURE__ */ jsxDEV(Type, { orderType: "options" }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/OrderPage.jsx",
        lineNumber: 19,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/OrderPage.jsx",
        lineNumber: 18,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/OrderPage.jsx",
      lineNumber: 14,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "text-center mt-4", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "fw-bold", children: [
        "총 금액: ",
        isNaN(totals.total) ? 0 : totals.total.toLocaleString(),
        "원"
      ] }, void 0, true, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/OrderPage.jsx",
        lineNumber: 23,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary btn-lg mt-3", onClick: () => setStep(1), children: "주문하기" }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/OrderPage.jsx",
        lineNumber: 24,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/OrderPage.jsx",
      lineNumber: 22,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/OrderPage.jsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
}
_s(OrderPage, "hjmxmtHue1q6LcYff49nUpy8jAU=");
_c = OrderPage;
export default OrderPage;
var _c;
$RefreshReg$(_c, "OrderPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/OrderPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU1k7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBVFosT0FBT0EsU0FBU0Msa0JBQWtCO0FBQ2xDLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPQyxVQUFVO0FBRWpCLFNBQVNDLFVBQVU7QUFBQSxFQUFFQztBQUFRLEdBQUc7QUFBQUMsS0FBQTtBQUM1QixRQUFNLENBQUM7QUFBQSxJQUFFQztBQUFBQSxFQUFPLENBQUMsSUFBSU4sV0FBV0MsWUFBWTtBQUU1QyxTQUNJLHVCQUFDLFNBQ0c7QUFBQSwyQkFBQyxRQUFHLFdBQVUsb0JBQW1CLDRCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZDO0FBQUEsSUFDN0MsdUJBQUMsU0FBSSxXQUFVLE9BQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsWUFDWCxpQ0FBQyxRQUFLLFdBQVUsY0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQixLQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxZQUNYLGlDQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCLEtBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ1g7QUFBQSw2QkFBQyxRQUFHLFdBQVUsV0FBVTtBQUFBO0FBQUEsUUFBT00sTUFBTUQsT0FBT0UsS0FBSyxJQUFJLElBQUlGLE9BQU9FLE1BQU1DLGVBQWU7QUFBQSxRQUFFO0FBQUEsV0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RjtBQUFBLE1BQ3hGLHVCQUFDLFlBQU8sV0FBVSwrQkFBOEIsU0FBUyxNQUFNTCxRQUFRLENBQUMsR0FBRSxvQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxPQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkE7QUFFUjtBQUFDQyxHQXRCUUYsV0FBUztBQUFBTyxLQUFUUDtBQXdCVCxlQUFlQTtBQUFVLElBQUFPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZUNvbnRleHQiLCJPcmRlckNvbnRleHQiLCJUeXBlIiwiT3JkZXJQYWdlIiwic2V0U3RlcCIsIl9zIiwidG90YWxzIiwiaXNOYU4iLCJ0b3RhbCIsInRvTG9jYWxlU3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJPcmRlclBhZ2UuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VDb250ZXh0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBPcmRlckNvbnRleHQgfSBmcm9tIFwiLi4vLi4vY29udGV4dHMvT3JkZXJDb250ZXh0XCI7XG5pbXBvcnQgVHlwZSBmcm9tIFwiLi9UeXBlXCI7XG5cbmZ1bmN0aW9uIE9yZGVyUGFnZSh7IHNldFN0ZXAgfSkge1xuICAgIGNvbnN0IFt7IHRvdGFscyB9XSA9IHVzZUNvbnRleHQoT3JkZXJDb250ZXh0KTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbWItNFwiPvCfm6sg7Jes7ZaJIOyDge2SiCAg7KO866y4PC9oMT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbWQtNlwiPlxuICAgICAgICAgICAgICAgICAgICA8VHlwZSBvcmRlclR5cGU9XCJwcm9kdWN0c1wiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbWQtNlwiPlxuICAgICAgICAgICAgICAgICAgICA8VHlwZSBvcmRlclR5cGU9XCJvcHRpb25zXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtdC00XCI+XG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZ3LWJvbGRcIj7stJ0g6riI7JWhOiB7aXNOYU4odG90YWxzLnRvdGFsKSA/IDAgOiB0b3RhbHMudG90YWwudG9Mb2NhbGVTdHJpbmcoKX3sm5A8L2gyPlxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1sZyBtdC0zXCIgb25DbGljaz17KCkgPT4gc2V0U3RlcCgxKX0+XG4gICAgICAgICAgICAgICAgICAgIOyjvOusuO2VmOq4sFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IE9yZGVyUGFnZTtcbiJdLCJmaWxlIjoiL1VzZXJzL2ppaHllb24vV2Vic3Rvcm1Qcm9qZWN0cy9yZWFjdC10ZXN0LXNob3AvcmVhY3Qtc2hvcC12aXRlLXRkZC1jbGllbnQvc3JjL3BhZ2VzL09yZGVyUGFnZS9PcmRlclBhZ2UuanN4In0=