import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=73008799"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=73008799"; const useState = __vite__cjsImport3_react["useState"];
import { BrowserRouter as Router, Routes, Route } from "/node_modules/.vite/deps/react-router-dom.js?v=73008799";
import OrderPage from "/src/pages/OrderPage/OrderPage.jsx?t=1741328457985";
import CompletePage from "/src/pages/CompletePage/CompletePage.jsx";
import SummaryPage from "/src/pages/SummaryPage/SummaryPage.jsx";
import WishlistPage from "/src/pages/WishlistPage/WishlistPage.jsx";
import { WishlistProvider } from "/src/contexts/WishlistContext.jsx";
import { OrderContextProvider } from "/src/contexts/OrderContext.jsx";
import Header from "/src/components/Header.jsx";
import "/node_modules/bootstrap/dist/css/bootstrap.min.css";
function App() {
  _s();
  const [step, setStep] = useState(0);
  return /* @__PURE__ */ jsxDEV("div", { className: "App", children: /* @__PURE__ */ jsxDEV(WishlistProvider, { children: /* @__PURE__ */ jsxDEV(OrderContextProvider, { children: /* @__PURE__ */ jsxDEV(Router, { children: [
    /* @__PURE__ */ jsxDEV(Header, {}, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx",
      lineNumber: 19,
      columnNumber: 25
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: {
      marginTop: "50px",
      marginLeft: "auto",
      marginRight: "auto",
      width: "80%"
    }, children: /* @__PURE__ */ jsxDEV(Routes, { children: [
      /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV("div", { className: "card p-4 shadow-lg", children: [
        step === 0 && /* @__PURE__ */ jsxDEV(OrderPage, { setStep }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx",
          lineNumber: 28,
          columnNumber: 60
        }, this),
        step === 1 && /* @__PURE__ */ jsxDEV(SummaryPage, { setStep }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx",
          lineNumber: 29,
          columnNumber: 60
        }, this),
        step === 2 && /* @__PURE__ */ jsxDEV(CompletePage, { setStep }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx",
          lineNumber: 30,
          columnNumber: 60
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx",
        lineNumber: 27,
        columnNumber: 58
      }, this) }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx",
        lineNumber: 27,
        columnNumber: 33
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/wishlist", element: /* @__PURE__ */ jsxDEV(WishlistPage, {}, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx",
        lineNumber: 32,
        columnNumber: 66
      }, this) }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx",
        lineNumber: 32,
        columnNumber: 33
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx",
      lineNumber: 26,
      columnNumber: 29
    }, this) }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx",
      lineNumber: 20,
      columnNumber: 25
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx",
    lineNumber: 18,
    columnNumber: 21
  }, this) }, void 0, false, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx",
    lineNumber: 17,
    columnNumber: 17
  }, this) }, void 0, false, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx",
    lineNumber: 16,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx",
    lineNumber: 15,
    columnNumber: 10
  }, this);
}
_s(App, "5L63dQvunH1XgKOLcNNkxeDh1IM=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJ3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFuQnhCLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxpQkFBaUJDLFFBQVFDLFFBQVFDLGFBQWE7QUFDdkQsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0MsNEJBQTRCO0FBQ3JDLE9BQU9DLFlBQVk7QUFDbkIsT0FBTztBQUVQLFNBQVNDLE1BQU07QUFBQUMsS0FBQTtBQUNYLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJZixTQUFTLENBQUM7QUFFbEMsU0FDSSx1QkFBQyxTQUFJLFdBQVUsT0FDWCxpQ0FBQyxvQkFDRyxpQ0FBQyx3QkFDRyxpQ0FBQyxVQUNHO0FBQUEsMkJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxJQUNQLHVCQUFDLFNBQ0csT0FBTztBQUFBLE1BQ0hnQixXQUFXO0FBQUEsTUFDWEMsWUFBWTtBQUFBLE1BQ1pDLGFBQWE7QUFBQSxNQUNiQyxPQUFPO0FBQUEsSUFDWCxHQUVBLGlDQUFDLFVBQ0c7QUFBQSw2QkFBQyxTQUNHLE1BQUssS0FDTCxTQUNJLHVCQUFDLFNBQUksV0FBVSxzQkFDVkw7QUFBQUEsaUJBQVMsS0FBSyx1QkFBQyxhQUFVLFdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFFBQzFDQSxTQUFTLEtBQUssdUJBQUMsZUFBWSxXQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEI7QUFBQSxRQUM1Q0EsU0FBUyxLQUFLLHVCQUFDLGdCQUFhLFdBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQjtBQUFBLFdBSGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQSxLQVBSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRSztBQUFBLE1BRUwsdUJBQUMsU0FBTSxNQUFLLGFBQVksU0FBUyx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWEsS0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRDtBQUFBLFNBWHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQSxLQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBO0FBQUEsT0F2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdCQSxLQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMEJBLEtBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0QkEsS0E3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThCQTtBQUVSO0FBQUNELEdBcENRRCxLQUFHO0FBQUFRLEtBQUhSO0FBc0NULGVBQWVBO0FBQUksSUFBQVE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQnJvd3NlclJvdXRlciIsIlJvdXRlciIsIlJvdXRlcyIsIlJvdXRlIiwiT3JkZXJQYWdlIiwiQ29tcGxldGVQYWdlIiwiU3VtbWFyeVBhZ2UiLCJXaXNobGlzdFBhZ2UiLCJXaXNobGlzdFByb3ZpZGVyIiwiT3JkZXJDb250ZXh0UHJvdmlkZXIiLCJIZWFkZXIiLCJBcHAiLCJfcyIsInN0ZXAiLCJzZXRTdGVwIiwibWFyZ2luVG9wIiwibWFyZ2luTGVmdCIsIm1hcmdpblJpZ2h0Iiwid2lkdGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEJyb3dzZXJSb3V0ZXIgYXMgUm91dGVyLCBSb3V0ZXMsIFJvdXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCBPcmRlclBhZ2UgZnJvbSBcIi4vcGFnZXMvT3JkZXJQYWdlL09yZGVyUGFnZVwiO1xuaW1wb3J0IENvbXBsZXRlUGFnZSBmcm9tIFwiLi9wYWdlcy9Db21wbGV0ZVBhZ2UvQ29tcGxldGVQYWdlXCI7XG5pbXBvcnQgU3VtbWFyeVBhZ2UgZnJvbSBcIi4vcGFnZXMvU3VtbWFyeVBhZ2UvU3VtbWFyeVBhZ2VcIjtcbmltcG9ydCBXaXNobGlzdFBhZ2UgZnJvbSBcIi4vcGFnZXMvV2lzaGxpc3RQYWdlL1dpc2hsaXN0UGFnZVwiO1xuaW1wb3J0IHsgV2lzaGxpc3RQcm92aWRlciB9IGZyb20gXCIuL2NvbnRleHRzL1dpc2hsaXN0Q29udGV4dFwiO1xuaW1wb3J0IHsgT3JkZXJDb250ZXh0UHJvdmlkZXIgfSBmcm9tIFwiLi9jb250ZXh0cy9PcmRlckNvbnRleHRcIjtcbmltcG9ydCBIZWFkZXIgZnJvbSBcIi4vY29tcG9uZW50cy9IZWFkZXJcIjtcbmltcG9ydCBcImJvb3RzdHJhcC9kaXN0L2Nzcy9ib290c3RyYXAubWluLmNzc1wiO1xuXG5mdW5jdGlvbiBBcHAoKSB7XG4gICAgY29uc3QgW3N0ZXAsIHNldFN0ZXBdID0gdXNlU3RhdGUoMCk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIkFwcFwiPlxuICAgICAgICAgICAgPFdpc2hsaXN0UHJvdmlkZXI+XG4gICAgICAgICAgICAgICAgPE9yZGVyQ29udGV4dFByb3ZpZGVyPlxuICAgICAgICAgICAgICAgICAgICA8Um91dGVyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEhlYWRlciAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpblRvcDogXCI1MHB4XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbkxlZnQ6IFwiYXV0b1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW5SaWdodDogXCJhdXRvXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiBcIjgwJVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJvdXRlcz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXRoPVwiL1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50PXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC00IHNoYWRvdy1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RlcCA9PT0gMCAmJiA8T3JkZXJQYWdlIHNldFN0ZXA9e3NldFN0ZXB9IC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RlcCA9PT0gMSAmJiA8U3VtbWFyeVBhZ2Ugc2V0U3RlcD17c2V0U3RlcH0gLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdGVwID09PSAyICYmIDxDb21wbGV0ZVBhZ2Ugc2V0U3RlcD17c2V0U3RlcH0gLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3dpc2hsaXN0XCIgZWxlbWVudD17PFdpc2hsaXN0UGFnZSAvPn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1JvdXRlcz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L1JvdXRlcj5cbiAgICAgICAgICAgICAgICA8L09yZGVyQ29udGV4dFByb3ZpZGVyPlxuICAgICAgICAgICAgPC9XaXNobGlzdFByb3ZpZGVyPlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBBcHA7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qaWh5ZW9uL1dlYnN0b3JtUHJvamVjdHMvcmVhY3QtdGVzdC1zaG9wL3JlYWN0LXNob3Atdml0ZS10ZGQtY2xpZW50L3NyYy9BcHAuanN4In0=