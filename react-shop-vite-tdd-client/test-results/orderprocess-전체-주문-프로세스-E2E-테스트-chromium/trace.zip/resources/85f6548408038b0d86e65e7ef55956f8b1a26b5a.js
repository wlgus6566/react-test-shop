import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/OrderPage/Type.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=73008799"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Type.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=73008799"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useContext = __vite__cjsImport3_react["useContext"];
import axios from "/node_modules/.vite/deps/axios.js?v=73008799";
import Products from "/src/pages/OrderPage/Products.jsx";
import Options from "/src/pages/OrderPage/Options.jsx";
import ErrorBanner from "/src/components/ErrorBanner.jsx";
import { OrderContext } from "/src/contexts/OrderContext.jsx";
import "/src/pages/OrderPage/style/OrderPage.css";
function Type({
  orderType
}) {
  _s();
  const [items, setItems] = useState([]);
  const [error, setError] = useState(false);
  const [{
    totals
  }, updateItemCount] = useContext(OrderContext);
  useEffect(() => {
    loadItems(orderType);
  }, [orderType]);
  const loadItems = async () => {
    try {
      let response = await axios.get(`http://localhost:5003/${orderType}`);
      setItems(response.data);
    } catch (error2) {
      setError(true);
    }
  };
  if (error) {
    return /* @__PURE__ */ jsxDEV(ErrorBanner, { message: "에러가 발생했습니다." }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Type.jsx",
      lineNumber: 30,
      columnNumber: 12
    }, this);
  }
  const ItemComponent = orderType === "products" ? Products : Options;
  const orderTypeKorean = orderType === "products" ? "상품" : "옵션";
  const totalPrice = totals[orderType] || 0;
  const formattedPrice = isNaN(totalPrice) ? 0 : totalPrice;
  return /* @__PURE__ */ jsxDEV("div", { className: "card p-3 shadow-sm", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-center text-primary", children: [
      orderTypeKorean,
      " 선택"
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Type.jsx",
      lineNumber: 39,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-center", children: "개별 가격" }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Type.jsx",
      lineNumber: 40,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("h4", { className: "text-center fw-bold text-danger", children: orderType === "products" ? `총 상품 가격: ${formattedPrice.toLocaleString()}원` : `총 옵션 가격: ${formattedPrice.toLocaleString()}원` }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Type.jsx",
      lineNumber: 41,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "row mt-3 type", children: items.map((item) => /* @__PURE__ */ jsxDEV("div", { className: "col-md-6", children: /* @__PURE__ */ jsxDEV(ItemComponent, { name: item.name, imagePath: item.imagePath, updateItemCount: (name, count) => updateItemCount(name, count, orderType) }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Type.jsx",
      lineNumber: 46,
      columnNumber: 25
    }, this) }, item.name, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Type.jsx",
      lineNumber: 45,
      columnNumber: 36
    }, this)) }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Type.jsx",
      lineNumber: 44,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Type.jsx",
    lineNumber: 38,
    columnNumber: 10
  }, this);
}
_s(Type, "dIVkh+bkQ+WcAfwL7NM+g9XcGbQ=");
_c = Type;
export default Type;
var _c;
$RefreshReg$(_c, "Type");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/OrderPage/Type.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJlOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNCZixPQUFPQSxTQUFTQyxXQUFXQyxVQUFVQyxrQkFBa0I7QUFDdkQsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsaUJBQWlCO0FBQ3hCLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPO0FBRVAsU0FBU0MsS0FBSztBQUFBLEVBQUVDO0FBQVUsR0FBRztBQUFBQyxLQUFBO0FBQ3pCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJWCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDWSxPQUFPQyxRQUFRLElBQUliLFNBQVMsS0FBSztBQUN4QyxRQUFNLENBQUM7QUFBQSxJQUFFYztBQUFBQSxFQUFPLEdBQUdDLGVBQWUsSUFBSWQsV0FBV0ssWUFBWTtBQUU3RFAsWUFBVSxNQUFNO0FBQ1ppQixjQUFVUixTQUFTO0FBQUEsRUFDdkIsR0FBRyxDQUFDQSxTQUFTLENBQUM7QUFFZCxRQUFNUSxZQUFZLFlBQVk7QUFDMUIsUUFBSTtBQUNBLFVBQUlDLFdBQVcsTUFBTWYsTUFBTWdCLElBQUsseUJBQXdCVixTQUFVLEVBQUM7QUFDbkVHLGVBQVNNLFNBQVNFLElBQUk7QUFBQSxJQUMxQixTQUFTUCxRQUFPO0FBQ1pDLGVBQVMsSUFBSTtBQUFBLElBQ2pCO0FBQUEsRUFDSjtBQUVBLE1BQUlELE9BQU87QUFDUCxXQUFPLHVCQUFDLGVBQVksU0FBUSxpQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrQztBQUFBLEVBQzdDO0FBRUEsUUFBTVEsZ0JBQWdCWixjQUFjLGFBQWFMLFdBQVdDO0FBQzVELFFBQU1pQixrQkFBa0JiLGNBQWMsYUFBYSxPQUFPO0FBRzFELFFBQU1jLGFBQWFSLE9BQU9OLFNBQVMsS0FBSztBQUN4QyxRQUFNZSxpQkFBaUJDLE1BQU1GLFVBQVUsSUFBSSxJQUFJQTtBQUUvQyxTQUNJLHVCQUFDLFNBQUksV0FBVSxzQkFDWDtBQUFBLDJCQUFDLFFBQUcsV0FBVSw0QkFBNEJEO0FBQUFBO0FBQUFBLE1BQWdCO0FBQUEsU0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RDtBQUFBLElBQzdELHVCQUFDLE9BQUUsV0FBVSxlQUFjLHFCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdDO0FBQUEsSUFDaEMsdUJBQUMsUUFBRyxXQUFVLG1DQUNUYix3QkFBYyxhQUNSLFlBQVdlLGVBQWVFLGVBQWUsQ0FBRSxNQUMzQyxZQUFXRixlQUFlRSxlQUFlLENBQUUsT0FIdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1ZmLGdCQUFNZ0IsSUFBS0MsVUFDUix1QkFBQyxTQUFJLFdBQVUsWUFDWCxpQ0FBQyxpQkFDRyxNQUFNQSxLQUFLQyxNQUNYLFdBQVdELEtBQUtFLFdBQ2hCLGlCQUFpQixDQUFDRCxNQUFNRSxVQUFVZixnQkFBZ0JhLE1BQU1FLE9BQU90QixTQUFTLEtBSDVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHOEUsS0FKbkRtQixLQUFLQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUEsQ0FDSCxLQVRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLE9BbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQkE7QUFFUjtBQUFDbkIsR0FuRFFGLE1BQUk7QUFBQXdCLEtBQUp4QjtBQXFEVCxlQUFlQTtBQUFLLElBQUF3QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZUNvbnRleHQiLCJheGlvcyIsIlByb2R1Y3RzIiwiT3B0aW9ucyIsIkVycm9yQmFubmVyIiwiT3JkZXJDb250ZXh0IiwiVHlwZSIsIm9yZGVyVHlwZSIsIl9zIiwiaXRlbXMiLCJzZXRJdGVtcyIsImVycm9yIiwic2V0RXJyb3IiLCJ0b3RhbHMiLCJ1cGRhdGVJdGVtQ291bnQiLCJsb2FkSXRlbXMiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJJdGVtQ29tcG9uZW50Iiwib3JkZXJUeXBlS29yZWFuIiwidG90YWxQcmljZSIsImZvcm1hdHRlZFByaWNlIiwiaXNOYU4iLCJ0b0xvY2FsZVN0cmluZyIsIm1hcCIsIml0ZW0iLCJuYW1lIiwiaW1hZ2VQYXRoIiwiY291bnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlR5cGUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VDb250ZXh0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XG5pbXBvcnQgUHJvZHVjdHMgZnJvbSBcIi4vUHJvZHVjdHNcIjtcbmltcG9ydCBPcHRpb25zIGZyb20gXCIuL09wdGlvbnNcIjtcbmltcG9ydCBFcnJvckJhbm5lciBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9FcnJvckJhbm5lclwiO1xuaW1wb3J0IHsgT3JkZXJDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2NvbnRleHRzL09yZGVyQ29udGV4dFwiO1xuaW1wb3J0IFwiLi9zdHlsZS9PcmRlclBhZ2UuY3NzXCI7XG5cbmZ1bmN0aW9uIFR5cGUoeyBvcmRlclR5cGUgfSkge1xuICAgIGNvbnN0IFtpdGVtcywgc2V0SXRlbXNdID0gdXNlU3RhdGUoW10pO1xuICAgIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFt7IHRvdGFscyB9LCB1cGRhdGVJdGVtQ291bnRdID0gdXNlQ29udGV4dChPcmRlckNvbnRleHQpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgbG9hZEl0ZW1zKG9yZGVyVHlwZSk7XG4gICAgfSwgW29yZGVyVHlwZV0pO1xuXG4gICAgY29uc3QgbG9hZEl0ZW1zID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gYXdhaXQgYXhpb3MuZ2V0KGBodHRwOi8vbG9jYWxob3N0OjUwMDMvJHtvcmRlclR5cGV9YCk7XG4gICAgICAgICAgICBzZXRJdGVtcyhyZXNwb25zZS5kYXRhKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHNldEVycm9yKHRydWUpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGlmIChlcnJvcikge1xuICAgICAgICByZXR1cm4gPEVycm9yQmFubmVyIG1lc3NhZ2U9XCLsl5Drn6zqsIAg67Cc7IOd7ZaI7Iq164uI64ukLlwiIC8+O1xuICAgIH1cblxuICAgIGNvbnN0IEl0ZW1Db21wb25lbnQgPSBvcmRlclR5cGUgPT09IFwicHJvZHVjdHNcIiA/IFByb2R1Y3RzIDogT3B0aW9ucztcbiAgICBjb25zdCBvcmRlclR5cGVLb3JlYW4gPSBvcmRlclR5cGUgPT09IFwicHJvZHVjdHNcIiA/IFwi7IOB7ZKIXCIgOiBcIuyYteyFmFwiO1xuICAgIFxuICAgIC8vIHRvdGFsUHJpY2XqsIAgdW5kZWZpbmVkLCBOYU4sIG51bGzsnbgg6rK97JqwIDDsnLzroZwg7LKY66asXG4gICAgY29uc3QgdG90YWxQcmljZSA9IHRvdGFsc1tvcmRlclR5cGVdIHx8IDA7XG4gICAgY29uc3QgZm9ybWF0dGVkUHJpY2UgPSBpc05hTih0b3RhbFByaWNlKSA/IDAgOiB0b3RhbFByaWNlO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtMyBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXByaW1hcnlcIj57b3JkZXJUeXBlS29yZWFufSDshKDtg508L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj7qsJzrs4Qg6rCA6rKpPC9wPlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZ3LWJvbGQgdGV4dC1kYW5nZXJcIj5cbiAgICAgICAgICAgICAgICB7b3JkZXJUeXBlID09PSBcInByb2R1Y3RzXCJcbiAgICAgICAgICAgICAgICAgICAgPyBg7LSdIOyDge2SiCDqsIDqsqk6ICR7Zm9ybWF0dGVkUHJpY2UudG9Mb2NhbGVTdHJpbmcoKX3sm5BgXG4gICAgICAgICAgICAgICAgICAgIDogYOy0nSDsmLXshZgg6rCA6rKpOiAke2Zvcm1hdHRlZFByaWNlLnRvTG9jYWxlU3RyaW5nKCl97JuQYH1cbiAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBtdC0zIHR5cGVcIj5cbiAgICAgICAgICAgICAgICB7aXRlbXMubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTZcIiBrZXk9e2l0ZW0ubmFtZX0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8SXRlbUNvbXBvbmVudFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e2l0ZW0ubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbWFnZVBhdGg9e2l0ZW0uaW1hZ2VQYXRofVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUl0ZW1Db3VudD17KG5hbWUsIGNvdW50KSA9PiB1cGRhdGVJdGVtQ291bnQobmFtZSwgY291bnQsIG9yZGVyVHlwZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBUeXBlOyJdLCJmaWxlIjoiL1VzZXJzL2ppaHllb24vV2Vic3Rvcm1Qcm9qZWN0cy9yZWFjdC10ZXN0LXNob3AvcmVhY3Qtc2hvcC12aXRlLXRkZC1jbGllbnQvc3JjL3BhZ2VzL09yZGVyUGFnZS9UeXBlLmpzeCJ9