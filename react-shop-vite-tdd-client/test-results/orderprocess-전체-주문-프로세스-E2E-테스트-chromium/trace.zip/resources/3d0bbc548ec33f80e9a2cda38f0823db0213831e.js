import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CompletePage/CompletePage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=73008799"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import axios from "/node_modules/.vite/deps/axios.js?v=73008799";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=73008799"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useContext = __vite__cjsImport4_react["useContext"]; const useState = __vite__cjsImport4_react["useState"];
import ErrorBanner from "/src/components/ErrorBanner.jsx";
import { OrderContext } from "/src/contexts/OrderContext.jsx";
function CompletePage({
  setStep
}) {
  _s();
  const [{
    userPoints
  }, , resetOrderDatas] = useContext(OrderContext);
  const [orderHistory, setOrderHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  useEffect(() => {
    fetchOrderHistory();
  }, []);
  const fetchOrderHistory = async () => {
    try {
      const response = await axios.get("http://localhost:5003/order-history");
      setOrderHistory(response.data);
      setLoading(false);
    } catch (error2) {
      setError(true);
    }
  };
  const clearOrderHistory = async () => {
    try {
      await axios.delete("http://localhost:5003/order-history");
      setOrderHistory([]);
      console.log("✅ 주문 내역 초기화 완료");
    } catch (error2) {
      console.error("🚨 주문 내역 초기화 실패", error2);
    }
  };
  const handleClick = () => {
    resetOrderDatas();
    setOrderHistory([]);
    setStep(0);
  };
  if (error) {
    return /* @__PURE__ */ jsxDEV(ErrorBanner, { message: "에러가 발생했습니다." }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
      lineNumber: 45,
      columnNumber: 12
    }, this);
  }
  const orderTable = orderHistory.map((item) => /* @__PURE__ */ jsxDEV("tr", { children: [
    /* @__PURE__ */ jsxDEV("td", { children: item.orderNumber }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
      lineNumber: 48,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("td", { children: item.price }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
      lineNumber: 49,
      columnNumber: 13
    }, this)
  ] }, item.orderNumber, true, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
    lineNumber: 47,
    columnNumber: 47
  }, this));
  if (loading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "d-flex justify-content-center align-items-center", style: {
      minHeight: "200px"
    }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "spinner-border text-primary me-2", role: "status" }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
        lineNumber: 55,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "h5 mb-0", children: "Loading..." }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
        lineNumber: 56,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
      lineNumber: 52,
      columnNumber: 12
    }, this);
  } else {
    return /* @__PURE__ */ jsxDEV("div", { className: "container py-5", children: /* @__PURE__ */ jsxDEV("div", { className: "card shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "card-body", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-center mb-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "display-1 text-success mb-3", children: "✓" }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
          lineNumber: 63,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "card-title mb-3", children: "주문이 성공했습니다!" }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
          lineNumber: 64,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "alert alert-info", children: /* @__PURE__ */ jsxDEV("h5", { className: "mb-0", children: [
          "남은 포인트: ",
          /* @__PURE__ */ jsxDEV("strong", { children: [
            userPoints !== void 0 ? userPoints.toLocaleString() : 0,
            "원"
          ] }, void 0, true, {
            fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
            lineNumber: 67,
            columnNumber: 45
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
          lineNumber: 66,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
          lineNumber: 65,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
        lineNumber: 62,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-center mb-3", children: "주문 내역" }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
          lineNumber: 73,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "table-responsive", children: /* @__PURE__ */ jsxDEV("table", { className: "table table-hover", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "table-light", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { scope: "col", children: "주문 번호" }, void 0, false, {
              fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
              lineNumber: 78,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("th", { scope: "col", children: "주문 금액" }, void 0, false, {
              fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
              lineNumber: 79,
              columnNumber: 45
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
            lineNumber: 77,
            columnNumber: 41
          }, this) }, void 0, false, {
            fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
            lineNumber: 76,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { children: orderTable }, void 0, false, {
            fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
            lineNumber: 82,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
          lineNumber: 75,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
          lineNumber: 74,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
        lineNumber: 72,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "d-flex justify-content-center gap-3", children: [
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary", onClick: handleClick, children: "첫페이지로" }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
          lineNumber: 90,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-danger", onClick: clearOrderHistory, children: "주문 내역 초기화" }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
          lineNumber: 93,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
        lineNumber: 89,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
      lineNumber: 61,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
      lineNumber: 60,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx",
      lineNumber: 59,
      columnNumber: 12
    }, this);
  }
}
_s(CompletePage, "RDf6uvSDNU2KLbELHyYyQBr237E=");
_c = CompletePage;
export default CompletePage;
var _c;
$RefreshReg$(_c, "CompletePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/CompletePage/CompletePage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNlOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNDZixPQUFPQSxXQUFXO0FBQ2xCLFNBQVNDLFdBQVdDLFlBQVlDLGdCQUFnQjtBQUNoRCxPQUFPQyxpQkFBaUI7QUFDeEIsU0FBU0Msb0JBQW9CO0FBRTdCLFNBQVNDLGFBQWE7QUFBQSxFQUFFQztBQUFRLEdBQUc7QUFBQUMsS0FBQTtBQUMvQixRQUFNLENBQUM7QUFBQSxJQUFFQztBQUFBQSxFQUFXLEdBQUMsRUFBSUMsZUFBZSxJQUFJUixXQUFXRyxZQUFZO0FBQ25FLFFBQU0sQ0FBQ00sY0FBY0MsZUFBZSxJQUFJVCxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDVSxTQUFTQyxVQUFVLElBQUlYLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNZLE9BQU9DLFFBQVEsSUFBSWIsU0FBUyxLQUFLO0FBRXhDRixZQUFVLE1BQU07QUFDWmdCLHNCQUFrQjtBQUFBLEVBQ3RCLEdBQUcsRUFBRTtBQUVMLFFBQU1BLG9CQUFvQixZQUFZO0FBQ2xDLFFBQUk7QUFDQSxZQUFNQyxXQUFXLE1BQU1sQixNQUFNbUIsSUFBSSxxQ0FBcUM7QUFDdEVQLHNCQUFnQk0sU0FBU0UsSUFBSTtBQUM3Qk4saUJBQVcsS0FBSztBQUFBLElBQ3BCLFNBQVNDLFFBQU87QUFDWkMsZUFBUyxJQUFJO0FBQUEsSUFDakI7QUFBQSxFQUNKO0FBR0EsUUFBTUssb0JBQW9CLFlBQVk7QUFDbEMsUUFBSTtBQUNBLFlBQU1yQixNQUFNc0IsT0FBTyxxQ0FBcUM7QUFDeERWLHNCQUFnQixFQUFFO0FBQ2xCVyxjQUFRQyxJQUFJLGdCQUFnQjtBQUFBLElBQ2hDLFNBQVNULFFBQU87QUFDWlEsY0FBUVIsTUFBTSxtQkFBbUJBLE1BQUs7QUFBQSxJQUMxQztBQUFBLEVBQ0o7QUFFQSxRQUFNVSxjQUFjQSxNQUFNO0FBQ3RCZixvQkFBZ0I7QUFDaEJFLG9CQUFnQixFQUFFO0FBQ2xCTCxZQUFRLENBQUM7QUFBQSxFQUNiO0FBRUEsTUFBSVEsT0FBTztBQUNQLFdBQU8sdUJBQUMsZUFBWSxTQUFRLGlCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtDO0FBQUEsRUFDN0M7QUFFQSxRQUFNVyxhQUFhZixhQUFhZ0IsSUFBS0MsVUFDakMsdUJBQUMsUUFDRztBQUFBLDJCQUFDLFFBQUlBLGVBQUtDLGVBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQjtBQUFBLElBQ3RCLHVCQUFDLFFBQUlELGVBQUtFLFNBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQjtBQUFBLE9BRlhGLEtBQUtDLGFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBLENBQ0g7QUFFRCxNQUFJaEIsU0FBUztBQUNULFdBQ0ksdUJBQUMsU0FBSSxXQUFVLG9EQUFtRCxPQUFPO0FBQUEsTUFBRWtCLFdBQVc7QUFBQSxJQUFRLEdBQzFGO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG9DQUFtQyxNQUFLLFlBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0Q7QUFBQSxNQUMvRCx1QkFBQyxVQUFLLFdBQVUsV0FBVSwwQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLFNBRnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLEVBRVIsT0FBTztBQUNILFdBQ0ksdUJBQUMsU0FBSSxXQUFVLGtCQUNYLGlDQUFDLFNBQUksV0FBVSxrQkFDWCxpQ0FBQyxTQUFJLFdBQVUsYUFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSxvQkFDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSwrQkFBOEIsaUJBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5Qyx1QkFBQyxRQUFHLFdBQVUsbUJBQWtCLDJCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJDO0FBQUEsUUFDM0MsdUJBQUMsU0FBSSxXQUFVLG9CQUNYLGlDQUFDLFFBQUcsV0FBVSxRQUFNO0FBQUE7QUFBQSxVQUNSLHVCQUFDLFlBQVF0QjtBQUFBQSwyQkFBZXVCLFNBQVl2QixXQUFXd0IsZUFBZSxJQUFJO0FBQUEsWUFBRTtBQUFBLGVBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFFO0FBQUEsYUFEakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFVLG9CQUFtQixxQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQztBQUFBLFFBQ3RDLHVCQUFDLFNBQUksV0FBVSxvQkFDWCxpQ0FBQyxXQUFNLFdBQVUscUJBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsZUFDYixpQ0FBQyxRQUNHO0FBQUEsbUNBQUMsUUFBRyxPQUFNLE9BQU0scUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFCO0FBQUEsWUFDckIsdUJBQUMsUUFBRyxPQUFNLE9BQU0scUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFCO0FBQUEsZUFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQSxLQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFdBQ0lQLHdCQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQSxLQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFdBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ1g7QUFBQSwrQkFBQyxZQUNHLFdBQVUsbUJBQ1YsU0FBU0QsYUFBWSxxQkFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQSx1QkFBQyxZQUNHLFdBQVUsa0JBQ1YsU0FBU0osbUJBQWtCLHlCQUYvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLFNBekNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQ0EsS0EzQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRDQSxLQTdDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOENBO0FBQUEsRUFFUjtBQUNKO0FBQUNiLEdBMUdRRixjQUFZO0FBQUE0QixLQUFaNUI7QUE0R1QsZUFBZUE7QUFBYSxJQUFBNEI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbImF4aW9zIiwidXNlRWZmZWN0IiwidXNlQ29udGV4dCIsInVzZVN0YXRlIiwiRXJyb3JCYW5uZXIiLCJPcmRlckNvbnRleHQiLCJDb21wbGV0ZVBhZ2UiLCJzZXRTdGVwIiwiX3MiLCJ1c2VyUG9pbnRzIiwicmVzZXRPcmRlckRhdGFzIiwib3JkZXJIaXN0b3J5Iiwic2V0T3JkZXJIaXN0b3J5IiwibG9hZGluZyIsInNldExvYWRpbmciLCJlcnJvciIsInNldEVycm9yIiwiZmV0Y2hPcmRlckhpc3RvcnkiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJjbGVhck9yZGVySGlzdG9yeSIsImRlbGV0ZSIsImNvbnNvbGUiLCJsb2ciLCJoYW5kbGVDbGljayIsIm9yZGVyVGFibGUiLCJtYXAiLCJpdGVtIiwib3JkZXJOdW1iZXIiLCJwcmljZSIsIm1pbkhlaWdodCIsInVuZGVmaW5lZCIsInRvTG9jYWxlU3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb21wbGV0ZVBhZ2UuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlQ29udGV4dCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBFcnJvckJhbm5lciBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9FcnJvckJhbm5lclwiO1xuaW1wb3J0IHsgT3JkZXJDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2NvbnRleHRzL09yZGVyQ29udGV4dFwiO1xuXG5mdW5jdGlvbiBDb21wbGV0ZVBhZ2UoeyBzZXRTdGVwIH0pIHtcbiAgICBjb25zdCBbeyB1c2VyUG9pbnRzIH0sICwgcmVzZXRPcmRlckRhdGFzXSA9IHVzZUNvbnRleHQoT3JkZXJDb250ZXh0KTtcbiAgICBjb25zdCBbb3JkZXJIaXN0b3J5LCBzZXRPcmRlckhpc3RvcnldID0gdXNlU3RhdGUoW10pO1xuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICAgIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgZmV0Y2hPcmRlckhpc3RvcnkoKTtcbiAgICB9LCBbXSk7XG5cbiAgICBjb25zdCBmZXRjaE9yZGVySGlzdG9yeSA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXhpb3MuZ2V0KFwiaHR0cDovL2xvY2FsaG9zdDo1MDAzL29yZGVyLWhpc3RvcnlcIik7XG4gICAgICAgICAgICBzZXRPcmRlckhpc3RvcnkocmVzcG9uc2UuZGF0YSk7XG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHNldEVycm9yKHRydWUpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIOKchSDso7zrrLgg64K07JetIOy0iOq4sO2ZlCDtlajsiJgg7LaU6rCAXG4gICAgY29uc3QgY2xlYXJPcmRlckhpc3RvcnkgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCBheGlvcy5kZWxldGUoXCJodHRwOi8vbG9jYWxob3N0OjUwMDMvb3JkZXItaGlzdG9yeVwiKTtcbiAgICAgICAgICAgIHNldE9yZGVySGlzdG9yeShbXSk7IC8vIOKchSDtlITroaDtirjsl5DshJzrj4Qg7KO866y4IOuCtOyXrSDstIjquLDtmZRcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi4pyFIOyjvOusuCDrgrTsl60g7LSI6riw7ZmUIOyZhOujjFwiKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCLwn5qoIOyjvOusuCDrgrTsl60g7LSI6riw7ZmUIOyLpO2MqFwiLCBlcnJvcik7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlQ2xpY2sgPSAoKSA9PiB7XG4gICAgICAgIHJlc2V0T3JkZXJEYXRhcygpO1xuICAgICAgICBzZXRPcmRlckhpc3RvcnkoW10pOyAvLyDinIUg7KO866y4IOuCtOyXrSDstIjquLDtmZRcbiAgICAgICAgc2V0U3RlcCgwKTtcbiAgICB9O1xuXG4gICAgaWYgKGVycm9yKSB7XG4gICAgICAgIHJldHVybiA8RXJyb3JCYW5uZXIgbWVzc2FnZT1cIuyXkOufrOqwgCDrsJzsg53tlojsirXri4jri6QuXCIgLz47XG4gICAgfVxuXG4gICAgY29uc3Qgb3JkZXJUYWJsZSA9IG9yZGVySGlzdG9yeS5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgPHRyIGtleT17aXRlbS5vcmRlck51bWJlcn0+XG4gICAgICAgICAgICA8dGQ+e2l0ZW0ub3JkZXJOdW1iZXJ9PC90ZD5cbiAgICAgICAgICAgIDx0ZD57aXRlbS5wcmljZX08L3RkPlxuICAgICAgICA8L3RyPlxuICAgICkpO1xuXG4gICAgaWYgKGxvYWRpbmcpIHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1mbGV4IGp1c3RpZnktY29udGVudC1jZW50ZXIgYWxpZ24taXRlbXMtY2VudGVyXCIgc3R5bGU9e3sgbWluSGVpZ2h0OiBcIjIwMHB4XCIgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGlubmVyLWJvcmRlciB0ZXh0LXByaW1hcnkgbWUtMlwiIHJvbGU9XCJzdGF0dXNcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImg1IG1iLTBcIj5Mb2FkaW5nLi4uPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyIHB5LTVcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIG1iLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpc3BsYXktMSB0ZXh0LXN1Y2Nlc3MgbWItM1wiPuKckzwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJjYXJkLXRpdGxlIG1iLTNcIj7so7zrrLjsnbQg7ISx6rO17ZaI7Iq164uI64ukITwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbGVydCBhbGVydC1pbmZvXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJtYi0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDrgqjsnYAg7Y+s7J247Yq4OiA8c3Ryb25nPnt1c2VyUG9pbnRzICE9PSB1bmRlZmluZWQgPyB1c2VyUG9pbnRzLnRvTG9jYWxlU3RyaW5nKCkgOiAwfeybkDwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2g1PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtYi0zXCI+7KO866y4IOuCtOyXrTwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0YWJsZS1yZXNwb25zaXZlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ0YWJsZSB0YWJsZS1ob3ZlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cInRhYmxlLWxpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIj7so7zrrLgg67KI7Zi4PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCI+7KO866y4IOq4iOyVoTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29yZGVyVGFibGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1mbGV4IGp1c3RpZnktY29udGVudC1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDbGlja31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOyyq+2OmOydtOyngOuhnFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0biBidG4tZGFuZ2VyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17Y2xlYXJPcmRlckhpc3Rvcnl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDso7zrrLgg64K07JetIOy0iOq4sO2ZlFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICk7XG4gICAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBDb21wbGV0ZVBhZ2U7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qaWh5ZW9uL1dlYnN0b3JtUHJvamVjdHMvcmVhY3QtdGVzdC1zaG9wL3JlYWN0LXNob3Atdml0ZS10ZGQtY2xpZW50L3NyYy9wYWdlcy9Db21wbGV0ZVBhZ2UvQ29tcGxldGVQYWdlLmpzeCJ9