import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Header.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=73008799"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/Header.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=73008799"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=73008799";
import { useWishlist } from "/src/contexts/WishlistContext.jsx";
function Header() {
  _s();
  const {
    wishlist
  } = useWishlist();
  const location = useLocation();
  return /* @__PURE__ */ jsxDEV("header", { className: "bg-light py-3 shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "container", children: /* @__PURE__ */ jsxDEV("nav", { className: "d-flex justify-content-between align-items-center", children: [
    /* @__PURE__ */ jsxDEV(Link, { to: "/", className: "text-decoration-none", style: {
      color: "inherit"
    }, children: /* @__PURE__ */ jsxDEV("h1", { className: "h4 mb-0", children: "여행 상품점" }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/Header.jsx",
      lineNumber: 17,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/Header.jsx",
      lineNumber: 14,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "d-flex gap-4", children: [
      /* @__PURE__ */ jsxDEV(Link, { to: "/", className: `text-decoration-none ${location.pathname === "/" ? "fw-bold" : ""}`, style: {
        color: "inherit"
      }, children: "상품 주문" }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/Header.jsx",
        lineNumber: 21,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/wishlist", className: `text-decoration-none position-relative ${location.pathname === "/wishlist" ? "fw-bold" : ""}`, style: {
        color: "inherit"
      }, children: [
        "위시리스트",
        wishlist.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger", style: {
          fontSize: "0.7rem"
        }, children: [
          wishlist.length,
          /* @__PURE__ */ jsxDEV("span", { className: "visually-hidden", children: "위시리스트 개수" }, void 0, false, {
            fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/Header.jsx",
            lineNumber: 35,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/Header.jsx",
          lineNumber: 31,
          columnNumber: 39
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/Header.jsx",
        lineNumber: 27,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/Header.jsx",
      lineNumber: 20,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/Header.jsx",
    lineNumber: 13,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/Header.jsx",
    lineNumber: 12,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/Header.jsx",
    lineNumber: 11,
    columnNumber: 10
  }, this);
}
_s(Header, "h52sTQ9b8VjzSwdf/7ClZgKGfA4=", false, function() {
  return [useWishlist, useLocation];
});
_c = Header;
export default Header;
var _c;
$RefreshReg$(_c, "Header");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/components/Header.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJZOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpCWixPQUFPQSxXQUFXO0FBQ2xCLFNBQVNDLE1BQU1DLG1CQUFtQjtBQUNsQyxTQUFTQyxtQkFBbUI7QUFFNUIsU0FBU0MsU0FBUztBQUFBQyxLQUFBO0FBQ2hCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFTLElBQUlILFlBQVk7QUFDakMsUUFBTUksV0FBV0wsWUFBWTtBQUU3QixTQUNFLHVCQUFDLFlBQU8sV0FBVSwyQkFDaEIsaUNBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsU0FBSSxXQUFVLHFEQUNiO0FBQUEsMkJBQUMsUUFDQyxJQUFHLEtBQ0gsV0FBVSx3QkFDVixPQUFPO0FBQUEsTUFBRU0sT0FBTztBQUFBLElBQVUsR0FFMUIsaUNBQUMsUUFBRyxXQUFVLFdBQVUsc0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEIsS0FMaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSw2QkFBQyxRQUNDLElBQUcsS0FDSCxXQUFZLHdCQUF1QkQsU0FBU0UsYUFBYSxNQUFNLFlBQVksRUFBRyxJQUM5RSxPQUFPO0FBQUEsUUFBRUQsT0FBTztBQUFBLE1BQVUsR0FBRSxxQkFIOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFFQSx1QkFBQyxRQUNDLElBQUcsYUFDSCxXQUFZLDBDQUF5Q0QsU0FBU0UsYUFBYSxjQUFjLFlBQVksRUFBRyxJQUN4RyxPQUFPO0FBQUEsUUFBRUQsT0FBTztBQUFBLE1BQVUsR0FBRTtBQUFBO0FBQUEsUUFHM0JGLFNBQVNJLFNBQVMsS0FDakIsdUJBQUMsVUFDQyxXQUFVLG1GQUNWLE9BQU87QUFBQSxVQUFFQyxVQUFVO0FBQUEsUUFBUyxHQUUzQkw7QUFBQUEsbUJBQVNJO0FBQUFBLFVBQ1YsdUJBQUMsVUFBSyxXQUFVLG1CQUFrQix3QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEM7QUFBQSxhQUw1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxXQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLFNBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkE7QUFBQSxPQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUNBLEtBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxQ0EsS0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVDQTtBQUVKO0FBQUNMLEdBOUNRRCxRQUFNO0FBQUEsVUFDUUQsYUFDSkQsV0FBVztBQUFBO0FBQUFVLEtBRnJCUjtBQWdEVCxlQUFlQTtBQUFPLElBQUFRO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIkxpbmsiLCJ1c2VMb2NhdGlvbiIsInVzZVdpc2hsaXN0IiwiSGVhZGVyIiwiX3MiLCJ3aXNobGlzdCIsImxvY2F0aW9uIiwiY29sb3IiLCJwYXRobmFtZSIsImxlbmd0aCIsImZvbnRTaXplIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJIZWFkZXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IExpbmssIHVzZUxvY2F0aW9uIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IHVzZVdpc2hsaXN0IH0gZnJvbSBcIi4uL2NvbnRleHRzL1dpc2hsaXN0Q29udGV4dFwiO1xuXG5mdW5jdGlvbiBIZWFkZXIoKSB7XG4gIGNvbnN0IHsgd2lzaGxpc3QgfSA9IHVzZVdpc2hsaXN0KCk7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcblxuICByZXR1cm4gKFxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiYmctbGlnaHQgcHktMyBzaGFkb3ctc21cIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZC1mbGV4IGp1c3RpZnktY29udGVudC1iZXR3ZWVuIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgIDxMaW5rIFxuICAgICAgICAgICAgdG89XCIvXCIgXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWRlY29yYXRpb24tbm9uZVwiXG4gICAgICAgICAgICBzdHlsZT17eyBjb2xvcjogXCJpbmhlcml0XCIgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwiaDQgbWItMFwiPuyXrO2WiSDsg4HtkojsoJA8L2gxPlxuICAgICAgICAgIDwvTGluaz5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1mbGV4IGdhcC00XCI+XG4gICAgICAgICAgICA8TGluayBcbiAgICAgICAgICAgICAgdG89XCIvXCIgXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtZGVjb3JhdGlvbi1ub25lICR7bG9jYXRpb24ucGF0aG5hbWUgPT09ICcvJyA/ICdmdy1ib2xkJyA6ICcnfWB9XG4gICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiBcImluaGVyaXRcIiB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICDsg4Htkogg7KO866y4XG4gICAgICAgICAgICA8L0xpbms+XG5cbiAgICAgICAgICAgIDxMaW5rIFxuICAgICAgICAgICAgICB0bz1cIi93aXNobGlzdFwiIFxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LWRlY29yYXRpb24tbm9uZSBwb3NpdGlvbi1yZWxhdGl2ZSAke2xvY2F0aW9uLnBhdGhuYW1lID09PSAnL3dpc2hsaXN0JyA/ICdmdy1ib2xkJyA6ICcnfWB9XG4gICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiBcImluaGVyaXRcIiB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICDsnITsi5zrpqzsiqTtirhcbiAgICAgICAgICAgICAge3dpc2hsaXN0Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgIDxzcGFuIFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicG9zaXRpb24tYWJzb2x1dGUgdG9wLTAgc3RhcnQtMTAwIHRyYW5zbGF0ZS1taWRkbGUgYmFkZ2Ugcm91bmRlZC1waWxsIGJnLWRhbmdlclwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBmb250U2l6ZTogXCIwLjdyZW1cIiB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHt3aXNobGlzdC5sZW5ndGh9XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ2aXN1YWxseS1oaWRkZW5cIj7snITsi5zrpqzsiqTtirgg6rCc7IiYPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9uYXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2hlYWRlcj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyOyJdLCJmaWxlIjoiL1VzZXJzL2ppaHllb24vV2Vic3Rvcm1Qcm9qZWN0cy9yZWFjdC10ZXN0LXNob3AvcmVhY3Qtc2hvcC12aXRlLXRkZC1jbGllbnQvc3JjL2NvbXBvbmVudHMvSGVhZGVyLmpzeCJ9