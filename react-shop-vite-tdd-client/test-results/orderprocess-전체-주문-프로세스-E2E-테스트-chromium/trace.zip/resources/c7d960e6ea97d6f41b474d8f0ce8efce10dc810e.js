import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/WishlistPage/WishlistPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=73008799"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=73008799"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { useWishlist } from "/src/contexts/WishlistContext.jsx";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=73008799";
function WishlistPage() {
  _s();
  const {
    wishlist,
    removeFromWishlist
  } = useWishlist();
  const navigate = useNavigate();
  if (wishlist.length === 0) {
    return /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxDEV("p", { children: "위시리스트가 비어있습니다." }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx",
        lineNumber: 14,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary", onClick: () => navigate("/"), "data-testid": "browse-products-button", children: "상품 둘러보기" }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx",
        lineNumber: 15,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx",
      lineNumber: 13,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "container mt-4", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-center mb-4", children: "나의 위시리스트" }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx",
      lineNumber: 21,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "row", children: wishlist.map((product) => /* @__PURE__ */ jsxDEV("div", { className: "col-md-4 mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "card", children: [
      /* @__PURE__ */ jsxDEV("img", { src: `http://localhost:5003${product.imagePath}`, className: "card-img-top", alt: product.name, style: {
        height: "200px",
        objectFit: "cover"
      } }, void 0, false, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx",
        lineNumber: 25,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "card-body", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "card-title h5", children: product.name }, void 0, false, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx",
          lineNumber: 30,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "d-flex justify-content-between", children: [
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary", onClick: () => navigate(`/order`), "aria-label": `${product.name} 주문하기`, children: "주문하기" }, void 0, false, {
            fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx",
            lineNumber: 32,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline-danger", onClick: () => removeFromWishlist(product.name), "aria-label": `${product.name} 삭제하기`, children: "삭제하기" }, void 0, false, {
            fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx",
            lineNumber: 35,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx",
          lineNumber: 31,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx",
        lineNumber: 29,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx",
      lineNumber: 24,
      columnNumber: 13
    }, this) }, product.name, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx",
      lineNumber: 23,
      columnNumber: 34
    }, this)) }, void 0, false, {
      fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx",
      lineNumber: 22,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
}
_s(WishlistPage, "2NWIP9GApk+3Gn5Yi+hxYU3k5YA=", false, function() {
  return [useWishlist, useNavigate];
});
_c = WishlistPage;
export default WishlistPage;
var _c;
$RefreshReg$(_c, "WishlistPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jihyeon/WebstormProjects/react-test-shop/react-shop-vite-tdd-client/src/pages/WishlistPage/WishlistPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV1E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBWFIsT0FBT0EsV0FBVztBQUNsQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsbUJBQW1CO0FBRTVCLFNBQVNDLGVBQWU7QUFBQUMsS0FBQTtBQUN0QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBVUM7QUFBQUEsRUFBbUIsSUFBSUwsWUFBWTtBQUNyRCxRQUFNTSxXQUFXTCxZQUFZO0FBRTdCLE1BQUlHLFNBQVNHLFdBQVcsR0FBRztBQUN6QixXQUNFLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsNkJBQUMsT0FBRSw4QkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsTUFDakIsdUJBQUMsWUFDQyxXQUFVLG1CQUNWLFNBQVMsTUFBTUQsU0FBUyxHQUFHLEdBQzNCLGVBQVksMEJBQXdCLHVCQUh0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLDJCQUFDLFFBQUcsV0FBVSxvQkFBbUIsd0JBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUM7QUFBQSxJQUN6Qyx1QkFBQyxTQUFJLFdBQVUsT0FDWkYsbUJBQVNJLElBQUtDLGFBQ2IsdUJBQUMsU0FBdUIsV0FBVSxpQkFDaEMsaUNBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSw2QkFBQyxTQUNDLEtBQU0sd0JBQXVCQSxRQUFRQyxTQUFVLElBQy9DLFdBQVUsZ0JBQ1YsS0FBS0QsUUFBUUUsTUFDYixPQUFPO0FBQUEsUUFBRUMsUUFBUTtBQUFBLFFBQVNDLFdBQVc7QUFBQSxNQUFRLEtBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJaUQ7QUFBQSxNQUVqRCx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxpQkFBaUJKLGtCQUFRRSxRQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRDO0FBQUEsUUFDNUMsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsaUNBQUMsWUFDQyxXQUFVLG1CQUNWLFNBQVMsTUFBTUwsU0FBVSxRQUFPLEdBQ2hDLGNBQWEsR0FBRUcsUUFBUUUsSUFBSyxTQUFPLG9CQUhyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFDQSx1QkFBQyxZQUNDLFdBQVUsMEJBQ1YsU0FBUyxNQUFNTixtQkFBbUJJLFFBQVFFLElBQUksR0FDOUMsY0FBYSxHQUFFRixRQUFRRSxJQUFLLFNBQU8sb0JBSHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFdBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxTQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBLEtBM0JRRixRQUFRRSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBLENBQ0QsS0EvQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdDQTtBQUFBLE9BbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQ0E7QUFFSjtBQUFDUixHQXpEUUQsY0FBWTtBQUFBLFVBQ3NCRixhQUN4QkMsV0FBVztBQUFBO0FBQUFhLEtBRnJCWjtBQTJEVCxlQUFlQTtBQUFhLElBQUFZO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVdpc2hsaXN0IiwidXNlTmF2aWdhdGUiLCJXaXNobGlzdFBhZ2UiLCJfcyIsIndpc2hsaXN0IiwicmVtb3ZlRnJvbVdpc2hsaXN0IiwibmF2aWdhdGUiLCJsZW5ndGgiLCJtYXAiLCJwcm9kdWN0IiwiaW1hZ2VQYXRoIiwibmFtZSIsImhlaWdodCIsIm9iamVjdEZpdCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiV2lzaGxpc3RQYWdlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VXaXNobGlzdCB9IGZyb20gXCIuLi8uLi9jb250ZXh0cy9XaXNobGlzdENvbnRleHRcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcblxuZnVuY3Rpb24gV2lzaGxpc3RQYWdlKCkge1xuICBjb25zdCB7IHdpc2hsaXN0LCByZW1vdmVGcm9tV2lzaGxpc3QgfSA9IHVzZVdpc2hsaXN0KCk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcblxuICBpZiAod2lzaGxpc3QubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgPHA+7JyE7Iuc66as7Iqk7Yq46rCAIOu5hOyWtOyeiOyKteuLiOuLpC48L3A+XG4gICAgICAgIDxidXR0b24gXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5XCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShcIi9cIil9XG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJicm93c2UtcHJvZHVjdHMtYnV0dG9uXCJcbiAgICAgICAgPlxuICAgICAgICAgIOyDge2SiCDrkZjrn6zrs7TquLBcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lciBtdC00XCI+XG4gICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbWItNFwiPuuCmOydmCDsnITsi5zrpqzsiqTtirg8L2gyPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3dcIj5cbiAgICAgICAge3dpc2hsaXN0Lm1hcCgocHJvZHVjdCkgPT4gKFxuICAgICAgICAgIDxkaXYga2V5PXtwcm9kdWN0Lm5hbWV9IGNsYXNzTmFtZT1cImNvbC1tZC00IG1iLTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZFwiPlxuICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgc3JjPXtgaHR0cDovL2xvY2FsaG9zdDo1MDAzJHtwcm9kdWN0LmltYWdlUGF0aH1gfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhcmQtaW1nLXRvcFwiXG4gICAgICAgICAgICAgICAgYWx0PXtwcm9kdWN0Lm5hbWV9XG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiBcIjIwMHB4XCIsIG9iamVjdEZpdDogXCJjb3ZlclwiIH19XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5XCI+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImNhcmQtdGl0bGUgaDVcIj57cHJvZHVjdC5uYW1lfTwvaDM+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkLWZsZXgganVzdGlmeS1jb250ZW50LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9vcmRlcmApfVxuICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgJHtwcm9kdWN0Lm5hbWV9IOyjvOusuO2VmOq4sGB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIOyjvOusuO2VmOq4sFxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZS1kYW5nZXJcIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiByZW1vdmVGcm9tV2lzaGxpc3QocHJvZHVjdC5uYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YCR7cHJvZHVjdC5uYW1lfSDsgq3soJztlZjquLBgfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICDsgq3soJztlZjquLBcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBXaXNobGlzdFBhZ2U7Il0sImZpbGUiOiIvVXNlcnMvamloeWVvbi9XZWJzdG9ybVByb2plY3RzL3JlYWN0LXRlc3Qtc2hvcC9yZWFjdC1zaG9wLXZpdGUtdGRkLWNsaWVudC9zcmMvcGFnZXMvV2lzaGxpc3RQYWdlL1dpc2hsaXN0UGFnZS5qc3gifQ==